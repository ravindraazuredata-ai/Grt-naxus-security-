// src/services/api.js
// ─────────────────────────────────────────────────────────────
//  GRT Nexus Security — Centralised API client
//  All calls go through here; token refresh is automatic.
// ─────────────────────────────────────────────────────────────

const BASE = import.meta.env.VITE_API_URL || "http://localhost:5000/api";

// ── Token helpers ─────────────────────────────────────────────
const token = {
  get access()  { return localStorage.getItem("grt_access_token"); },
  get refresh() { return localStorage.getItem("grt_refresh_token"); },
  set(access, refresh) {
    localStorage.setItem("grt_access_token", access);
    if (refresh) localStorage.setItem("grt_refresh_token", refresh);
  },
  clear() {
    localStorage.removeItem("grt_access_token");
    localStorage.removeItem("grt_refresh_token");
    localStorage.removeItem("grt_user");
  },
};

// ── Core fetch wrapper ────────────────────────────────────────
let refreshPromise = null;

async function request(path, opts = {}) {
  const headers = {
    "Content-Type": "application/json",
    ...(token.access ? { Authorization: `Bearer ${token.access}` } : {}),
    ...opts.headers,
  };

  const res = await fetch(`${BASE}${path}`, { ...opts, headers });

  // Auto-refresh on 401
  if (res.status === 401 && token.refresh && !opts._retry) {
    if (!refreshPromise) {
      refreshPromise = fetch(`${BASE}/auth/refresh`, {
        method: "POST",
        headers: { "Content-Type": "application/json" },
        body: JSON.stringify({ refresh_token: token.refresh }),
      })
        .then((r) => r.json())
        .then((d) => {
          if (d.data?.access_token) token.set(d.data.access_token);
          else token.clear();
        })
        .finally(() => { refreshPromise = null; });
    }
    await refreshPromise;
    return request(path, { ...opts, _retry: true });
  }

  const data = await res.json();
  if (!res.ok) throw Object.assign(new Error(data.message || "Request failed"), { status: res.status, data });
  return data;
}

const get  = (path, opts)        => request(path, { method: "GET", ...opts });
const post = (path, body, opts)  => request(path, { method: "POST",  body: JSON.stringify(body), ...opts });
const patch = (path, body, opts) => request(path, { method: "PATCH", body: JSON.stringify(body), ...opts });
const del  = (path, opts)        => request(path, { method: "DELETE", ...opts });

// ═══════════════════════════════════════════════════════════════
//  AUTH
// ═══════════════════════════════════════════════════════════════
export const auth = {
  async login(email, password) {
    const data = await post("/auth/login", { email, password });
    const { user, access_token, refresh_token } = data.data;
    token.set(access_token, refresh_token);
    localStorage.setItem("grt_user", JSON.stringify(user));
    return user;
  },

  async logout() {
    try { await post("/auth/logout", { refresh_token: token.refresh }); } catch (_) {}
    token.clear();
  },

  async me() {
    const data = await get("/auth/me");
    return data.data.user;
  },

  async changePassword(current_password, new_password, confirm_password) {
    return post("/auth/change-password", { current_password, new_password, confirm_password });
  },

  currentUser() {
    try { return JSON.parse(localStorage.getItem("grt_user")); } catch { return null; }
  },

  isAuthenticated() {
    return !!token.access;
  },
};

// ═══════════════════════════════════════════════════════════════
//  DEVICES
// ═══════════════════════════════════════════════════════════════
export const devices = {
  list(params = {})          { return get(`/devices?${new URLSearchParams(params)}`).then(d => d.data); },
  summary()                  { return get("/devices/summary").then(d => d.data); },
  get(id)                    { return get(`/devices/${id}`).then(d => d.data.device); },
  create(body)               { return post("/devices", body).then(d => d.data.device); },
  update(id, body)           { return patch(`/devices/${id}`, body).then(d => d.data.device); },
  delete(id)                 { return del(`/devices/${id}`); },
  ping(id)                   { return post(`/devices/${id}/ping`).then(d => d.data); },
  scan(subnet)               { return post("/devices/scan", { subnet }); },
};

// ═══════════════════════════════════════════════════════════════
//  ALERTS
// ═══════════════════════════════════════════════════════════════
export const alerts = {
  list(params = {})    { return get(`/alerts?${new URLSearchParams(params)}`).then(d => d.data); },
  summary()            { return get("/alerts/summary").then(d => d.data); },
  get(id)              { return get(`/alerts/${id}`).then(d => d.data.alert); },
  create(body)         { return post("/alerts", body).then(d => d.data.alert); },
  acknowledge(id)      { return patch(`/alerts/${id}/acknowledge`).then(d => d.data.alert); },
  resolve(id)          { return patch(`/alerts/${id}/resolve`).then(d => d.data.alert); },
};

// ═══════════════════════════════════════════════════════════════
//  SURVEILLANCE
// ═══════════════════════════════════════════════════════════════
export const surveillance = {
  cameras(params = {})        { return get(`/surveillance/cameras?${new URLSearchParams(params)}`).then(d => d.data); },
  camera(id)                  { return get(`/surveillance/cameras/${id}`).then(d => d.data.camera); },
  addCamera(body)             { return post("/surveillance/cameras", body).then(d => d.data.camera); },
  snapshot(id)                { return get(`/surveillance/cameras/${id}/snapshot`).then(d => d.data); },
  ptz(id, action, speed = 5) { return post(`/surveillance/cameras/${id}/ptz`, { action, speed }); },
  motionEvents(params = {})   { return get(`/surveillance/motion-events?${new URLSearchParams(params)}`).then(d => d.data); },
  overview()                  { return get("/surveillance/overview").then(d => d.data); },
};

// ═══════════════════════════════════════════════════════════════
//  AUTOMATION
// ═══════════════════════════════════════════════════════════════
export const automation = {
  rules(params = {})       { return get(`/automation/rules?${new URLSearchParams(params)}`).then(d => d.data); },
  rule(id)                 { return get(`/automation/rules/${id}`).then(d => d.data.rule); },
  logs(id, limit = 20)     { return get(`/automation/rules/${id}/logs?limit=${limit}`).then(d => d.data.logs); },
  create(body)             { return post("/automation/rules", body).then(d => d.data.rule); },
  update(id, body)         { return patch(`/automation/rules/${id}`, body).then(d => d.data.rule); },
  toggle(id)               { return patch(`/automation/rules/${id}/toggle`).then(d => d.data.rule); },
  test(id, mock = {})      { return post(`/automation/rules/${id}/test`, { mock_event: mock }).then(d => d.data); },
  delete(id)               { return del(`/automation/rules/${id}`); },
  meta()                   { return get("/automation/meta").then(d => d.data); },
};

// ═══════════════════════════════════════════════════════════════
//  NOTIFICATIONS
// ═══════════════════════════════════════════════════════════════
export const notifications = {
  list(params = {})   { return get(`/notifications?${new URLSearchParams(params)}`).then(d => d.data); },
  count()             { return get("/notifications/count").then(d => d.data.unread_count); },
  markRead(id)        { return patch(`/notifications/${id}/read`); },
  markAllRead()       { return patch("/notifications/read-all"); },
};

// ═══════════════════════════════════════════════════════════════
//  USERS (admin)
// ═══════════════════════════════════════════════════════════════
export const users = {
  list(params = {})            { return get(`/users?${new URLSearchParams(params)}`).then(d => d.data); },
  get(id)                      { return get(`/users/${id}`).then(d => d.data.user); },
  create(body)                 { return post("/users", body).then(d => d.data.user); },
  update(id, body)             { return patch(`/users/${id}`, body).then(d => d.data.user); },
  deactivate(id)               { return del(`/users/${id}`); },
  resetPassword(id, new_password) { return patch(`/users/${id}/reset-password`, { new_password }); },
};

// ═══════════════════════════════════════════════════════════════
//  SYSTEM
// ═══════════════════════════════════════════════════════════════
export const system = {
  health()  { return get("/about/health").then(d => d.data); },
  about()   { return get("/about").then(d => d.data); },
};

export { token };
export default { auth, devices, alerts, surveillance, automation, notifications, users, system };
