// src/App.jsx
// ─────────────────────────────────────────────────────────────
//  GRT NEXUS SECURITY — Root application
//  Handles: auth gate, routing, WS, live device/alert updates
// ─────────────────────────────────────────────────────────────
import { useState, useEffect, useCallback } from "react";
import { AuthProvider, useAuth } from "./context/AuthContext";
import { NotificationProvider, useNotifications } from "./context/NotificationContext";
import { useWebSocket, EVENT_TYPES } from "./hooks/useWebSocket";
import { devices as devAPI, alerts as alertAPI, system } from "./services/api";
import SessionTimer from "./components/SessionTimer";
import NotificationBell from "./components/NotificationBell";
import AboutPage from "./pages/AboutPage";
import AutomationPanel from "./components/AutomationPanel";
import DeviceScanModal from "./components/DeviceScanModal";

// ── Theme ─────────────────────────────────────────────────────
const T = {
  bg: "#070B14", bgCard: "#0D1220", bgPanel: "#101828",
  border: "#1E2D45", accent: "#0EA5E9", accentAlt: "#F97316",
  green: "#22D3A5", red: "#EF4444", yellow: "#FBBF24", purple: "#A78BFA",
  text: "#E2EAF4", muted: "#64748B", glow: "rgba(14,165,233,0.15)",
};

// ── Inline icon ───────────────────────────────────────────────
const Icon = ({ d, size = 18, color = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
);

// ── Pulse dot ─────────────────────────────────────────────────
const PulseDot = ({ color = T.green, size = 8 }) => (
  <span style={{ position: "relative", display: "inline-block", width: size, height: size }}>
    <span style={{ position: "absolute", inset: 0, borderRadius: "50%", background: color, opacity: 0.4,
      animation: "ping 1.5s cubic-bezier(0,0,0.2,1) infinite" }}/>
    <span style={{ position: "absolute", inset: 0, borderRadius: "50%", background: color }}/>
  </span>
);

// ─────────────────────────────────────────────────────────────
//  NAV ITEMS
// ─────────────────────────────────────────────────────────────
const NAV = [
  { key: "dashboard",    label: "Dashboard",    icon: "M22 12h-4l-3 9L9 3l-3 9H2" },
  { key: "devices",      label: "Devices",      icon: "M9 3H7a2 2 0 0 0-2 2v2M9 3h6M15 3h2a2 2 0 0 1 2 2v2M21 9v6M21 15v2a2 2 0 0 1-2 2h-2M15 21H9M9 21H7a2 2 0 0 1-2-2v-2M3 15V9M9 9h6v6H9z" },
  { key: "alerts",       label: "Alerts",       icon: "M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0zM12 9v4M12 17h.01" },
  { key: "surveillance", label: "Surveillance", icon: "M15 10l4.553-2.069A1 1 0 0 1 21 8.87v6.26a1 1 0 0 1-1.447.939L15 14M3 8h12v8H3z" },
  { key: "automation",   label: "Automation",   icon: "M13 2L3 14h9l-1 8 10-12h-9l1-8z" },
  { key: "about",        label: "About",        icon: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" },
];

// ─────────────────────────────────────────────────────────────
//  LOGIN PAGE
// ─────────────────────────────────────────────────────────────
function LoginPage() {
  const { login } = useAuth();
  const [email, setEmail]   = useState("");
  const [pass, setPass]     = useState("");
  const [error, setError]   = useState("");
  const [loading, setLoading] = useState(false);

  const handleLogin = async () => {
    if (!email || !pass) return;
    setError(""); setLoading(true);
    try {
      await login(email, pass);
    } catch (e) {
      setError(e.message || "Login failed");
    } finally {
      setLoading(false);
    }
  };

  const inp = {
    width: "100%", background: T.bgPanel, border: `1px solid ${T.border}`,
    borderRadius: 10, padding: "12px 16px", color: T.text, fontSize: 14,
    fontFamily: "'Space Mono',monospace", outline: "none", boxSizing: "border-box",
  };

  return (
    <div style={{ minHeight: "100vh", background: T.bg, display: "flex",
      alignItems: "center", justifyContent: "center", padding: 24, position: "relative", overflow: "hidden" }}>
      {/* Animated grid bg */}
      <div style={{ position: "absolute", inset: 0, opacity: 0.04, pointerEvents: "none" }}>
        {Array.from({ length: 18 }).map((_, i) => (
          <div key={`h${i}`} style={{ position: "absolute", left: 0, right: 0, height: 1,
            top: `${i * 5.8}%`, background: `linear-gradient(90deg,transparent,${T.accent},transparent)` }}/>
        ))}
        {Array.from({ length: 22 }).map((_, i) => (
          <div key={`v${i}`} style={{ position: "absolute", top: 0, bottom: 0, width: 1,
            left: `${i * 4.7}%`, background: `linear-gradient(180deg,transparent,${T.accent},transparent)` }}/>
        ))}
      </div>
      <div style={{ position: "absolute", top: "20%", left: "25%", width: 500, height: 500,
        borderRadius: "50%", background: `radial-gradient(circle,${T.accent}10,transparent 70%)`,
        filter: "blur(60px)", pointerEvents: "none" }}/>

      <div style={{ position: "relative", width: 400, maxWidth: "100%" }}>
        <div style={{ textAlign: "center", marginBottom: 36 }}>
          <div style={{ fontFamily: "'Space Mono',monospace", fontSize: 11, color: T.accent,
            letterSpacing: 4, textTransform: "uppercase", marginBottom: 10 }}>
            GRT ASSIST AUTOMATIONS & SECURITY
          </div>
          <div style={{ fontSize: 26, fontWeight: 900, color: T.text, letterSpacing: -0.5 }}>
            NEXUS <span style={{ color: T.accent }}>SECURITY</span>
          </div>
          <div style={{ fontSize: 11, color: T.muted, marginTop: 6,
            fontFamily: "'Space Mono',monospace" }}>SECURE ACCESS PORTAL</div>
        </div>

        <div style={{ background: T.bgCard, border: `1px solid ${T.border}`, borderRadius: 18,
          padding: "32px 28px", display: "flex", flexDirection: "column", gap: 16 }}>
          {error && (
            <div style={{ padding: "10px 14px", borderRadius: 8, background: `${T.red}15`,
              border: `1px solid ${T.red}40`, fontSize: 12, color: T.red,
              fontFamily: "'Space Mono',monospace" }}>⚠ {error}</div>
          )}
          <div>
            <label style={{ fontSize: 10, color: T.muted, fontFamily: "'Space Mono',monospace",
              letterSpacing: 1, display: "block", marginBottom: 6 }}>EMAIL ADDRESS</label>
            <input type="email" value={email} onChange={(e) => setEmail(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleLogin()}
              placeholder="admin@grtassist.com" style={inp} />
          </div>
          <div>
            <label style={{ fontSize: 10, color: T.muted, fontFamily: "'Space Mono',monospace",
              letterSpacing: 1, display: "block", marginBottom: 6 }}>PASSWORD</label>
            <input type="password" value={pass} onChange={(e) => setPass(e.target.value)}
              onKeyDown={(e) => e.key === "Enter" && handleLogin()}
              placeholder="••••••••" style={inp} />
          </div>
          <button onClick={handleLogin} disabled={loading || !email || !pass} style={{
            background: `linear-gradient(135deg,${T.accent},${T.purple})`,
            border: "none", borderRadius: 10, padding: "13px",
            color: "#fff", fontFamily: "'Space Mono',monospace", fontSize: 13,
            cursor: loading ? "not-allowed" : "pointer", letterSpacing: 2,
            opacity: loading ? 0.7 : 1, marginTop: 4, fontWeight: 700,
          }}>
            {loading ? "AUTHENTICATING..." : "ACCESS SYSTEM →"}
          </button>
          <div style={{ textAlign: "center", fontSize: 10, color: T.muted,
            fontFamily: "'Space Mono',monospace" }}>
            ROLE-BASED ACCESS · SESSION MONITORED
          </div>
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  MAIN DASHBOARD SHELL
// ─────────────────────────────────────────────────────────────
function DashboardShell() {
  const { user, logout, isAdmin, isOperator } = useAuth();
  const { toast, pushNotification } = useNotifications();

  const [page, setPage]           = useState("dashboard");
  const [sidebarOpen, setSidebar] = useState(true);
  const [deviceSummary, setDeviceSummary] = useState(null);
  const [alertSummary, setAlertSummary]   = useState(null);
  const [recentAlerts, setRecentAlerts]   = useState([]);
  const [scanModal, setScanModal]         = useState(false);
  const [health, setHealth]               = useState(null);

  // ── Live data fetch ──────────────────────────────────────
  const loadDashboard = useCallback(async () => {
    try {
      const [ds, as, h] = await Promise.all([
        devAPI.summary(),
        alertAPI.summary(),
        system.health(),
      ]);
      setDeviceSummary(ds);
      setAlertSummary(as);
      setRecentAlerts(as.recent_critical || []);
      setHealth(h);
    } catch (e) {
      toast("error", "Data Load Failed", e.message);
    }
  }, []);

  useEffect(() => {
    loadDashboard();
    const id = setInterval(loadDashboard, 30_000);
    return () => clearInterval(id);
  }, [loadDashboard]);

  // ── WebSocket live updates ───────────────────────────────
  const { connected } = useWebSocket({
    [EVENT_TYPES.DEVICE_STATUS]: (data) => {
      setDeviceSummary((prev) => {
        if (!prev) return prev;
        const updated = { ...prev };
        // Simple optimistic status count flip — full re-fetch on next interval
        return updated;
      });
    },
    [EVENT_TYPES.ALERT_CREATED]: (data) => {
      toast("alert", "New Alert", data.title || "Security alert triggered");
      loadDashboard();
    },
    [EVENT_TYPES.DEVICE_DISCOVERED]: (data) => {
      toast("info", "Device Discovered", `New device found at ${data.ip_address}`);
    },
    [EVENT_TYPES.NOTIFICATION]: (data) => {
      pushNotification(data);
    },
  });

  // ── Nav items (filter by role) ───────────────────────────
  const navItems = NAV.filter((n) => {
    if (n.key === "automation") return isOperator;
    return true;
  });

  const SB_W = sidebarOpen ? 220 : 64;

  return (
    <div style={{ display: "flex", minHeight: "100vh", background: T.bg, color: T.text,
      fontFamily: "'Inter',system-ui,sans-serif" }}>

      {/* ── SIDEBAR ──────────────────────────────────────── */}
      <aside style={{
        width: SB_W, background: T.bgCard, borderRight: `1px solid ${T.border}`,
        display: "flex", flexDirection: "column", transition: "width 0.25s ease",
        overflow: "hidden", flexShrink: 0, position: "sticky", top: 0, height: "100vh",
      }}>
        {/* Logo */}
        <div style={{ padding: "20px 16px", borderBottom: `1px solid ${T.border}`,
          display: "flex", alignItems: "center", gap: 10, overflow: "hidden" }}>
          <div style={{ width: 32, height: 32, borderRadius: 8, background: `linear-gradient(135deg,${T.accent},${T.purple})`,
            display: "flex", alignItems: "center", justifyContent: "center", flexShrink: 0 }}>
            <Icon d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z" size={16} color="#fff" />
          </div>
          {sidebarOpen && (
            <div>
              <div style={{ fontSize: 13, fontWeight: 800, color: T.text, letterSpacing: -0.3 }}>
                GRT <span style={{ color: T.accent }}>NEXUS</span>
              </div>
              <div style={{ fontSize: 9, color: T.muted, fontFamily: "'Space Mono',monospace",
                letterSpacing: 1, textTransform: "uppercase" }}>SECURITY</div>
            </div>
          )}
        </div>

        {/* Nav */}
        <nav style={{ flex: 1, padding: "12px 8px", overflowY: "auto" }}>
          {navItems.map((item) => {
            const active = page === item.key;
            return (
              <button key={item.key} onClick={() => setPage(item.key)} style={{
                width: "100%", display: "flex", alignItems: "center",
                gap: 10, padding: sidebarOpen ? "10px 12px" : "10px",
                borderRadius: 8, border: "none", cursor: "pointer",
                background: active ? `${T.accent}18` : "transparent",
                borderLeft: active ? `2px solid ${T.accent}` : "2px solid transparent",
                color: active ? T.accent : T.muted, marginBottom: 2,
                transition: "all 0.15s", justifyContent: sidebarOpen ? "flex-start" : "center",
              }}
              onMouseEnter={(e) => { if (!active) e.currentTarget.style.background = `${T.accent}0A`; }}
              onMouseLeave={(e) => { if (!active) e.currentTarget.style.background = "transparent"; }}>
                <Icon d={item.icon} size={17} color={active ? T.accent : T.muted}/>
                {sidebarOpen && (
                  <span style={{ fontSize: 13, fontWeight: active ? 700 : 400, whiteSpace: "nowrap" }}>
                    {item.label}
                  </span>
                )}
              </button>
            );
          })}
        </nav>

        {/* Sidebar footer */}
        <div style={{ padding: "12px 8px", borderTop: `1px solid ${T.border}` }}>
          <button onClick={() => setSidebar((s) => !s)} style={{
            width: "100%", padding: "8px 12px", background: "none", border: "none",
            color: T.muted, cursor: "pointer", borderRadius: 6, fontSize: 16,
          }}>{sidebarOpen ? "‹ Collapse" : "›"}</button>
        </div>
      </aside>

      {/* ── MAIN AREA ─────────────────────────────────────── */}
      <div style={{ flex: 1, display: "flex", flexDirection: "column", overflow: "hidden" }}>

        {/* Top bar */}
        <header style={{ height: 60, background: T.bgCard, borderBottom: `1px solid ${T.border}`,
          display: "flex", alignItems: "center", padding: "0 24px", gap: 16, flexShrink: 0 }}>
          {/* WS status */}
          <div style={{ display: "flex", alignItems: "center", gap: 6 }}>
            <PulseDot color={connected ? T.green : T.red} size={6}/>
            <span style={{ fontSize: 10, color: T.muted, fontFamily: "'Space Mono',monospace" }}>
              {connected ? "LIVE" : "RECONNECTING"}
            </span>
          </div>

          {/* DB status */}
          {health && (
            <div style={{ fontSize: 10, color: health.database === "connected" ? T.green : T.red,
              fontFamily: "'Space Mono',monospace", display: "flex", alignItems: "center", gap: 4 }}>
              <div style={{ width: 5, height: 5, borderRadius: "50%",
                background: health.database === "connected" ? T.green : T.red }}/>
              DB {health.database === "connected" ? "OK" : "DOWN"}
            </div>
          )}

          <div style={{ flex: 1 }}/>

          {isOperator && (
            <button onClick={() => setScanModal(true)} style={{
              background: "none", border: `1px solid ${T.border}`, borderRadius: 8,
              padding: "6px 14px", color: T.muted, fontSize: 11, cursor: "pointer",
              fontFamily: "'Space Mono',monospace", letterSpacing: 1,
              display: "flex", alignItems: "center", gap: 6,
            }}>
              <Icon d="M12 12m-9 0a9 9 0 1 0 18 0a9 9 0 1 0-18 0M12 12m-4 0a4 4 0 1 0 8 0a4 4 0 1 0-8 0M12 12l3-5" size={14} color={T.muted}/>
              SCAN
            </button>
          )}

          <SessionTimer />
          <NotificationBell />

          {/* User chip */}
          <div style={{ display: "flex", alignItems: "center", gap: 8,
            background: T.bgPanel, border: `1px solid ${T.border}`,
            borderRadius: 8, padding: "6px 12px" }}>
            <div style={{ width: 26, height: 26, borderRadius: "50%",
              background: `linear-gradient(135deg,${T.accent},${T.purple})`,
              display: "flex", alignItems: "center", justifyContent: "center",
              fontSize: 11, fontWeight: 800, color: "#fff" }}>
              {user?.username?.charAt(0).toUpperCase() || "U"}
            </div>
            <div>
              <div style={{ fontSize: 12, fontWeight: 600, color: T.text }}>{user?.username}</div>
              <div style={{ fontSize: 9, color: T.muted, fontFamily: "'Space Mono',monospace",
                textTransform: "uppercase", letterSpacing: 1 }}>{user?.role}</div>
            </div>
            <button onClick={logout} title="Logout" style={{
              background: "none", border: "none", color: T.muted, cursor: "pointer",
              fontSize: 12, padding: 2, marginLeft: 4,
            }}>⏻</button>
          </div>
        </header>

        {/* Page content */}
        <main style={{ flex: 1, overflowY: "auto", padding: "24px" }}>
          {page === "dashboard" && (
            <DashboardPage
              deviceSummary={deviceSummary}
              alertSummary={alertSummary}
              recentAlerts={recentAlerts}
            />
          )}
          {page === "automation" && (
            <div>
              <div style={{ marginBottom: 24 }}>
                <div style={{ fontSize: 22, fontWeight: 800, color: T.text }}>Automation Rules</div>
                <div style={{ fontSize: 13, color: T.muted, marginTop: 4 }}>
                  Configure trigger-action pairs to automate your security responses.
                </div>
              </div>
              <AutomationPanel />
            </div>
          )}
          {page === "about" && <AboutPage />}
          {["devices","alerts","surveillance"].includes(page) && (
            <PlaceholderPage name={page} />
          )}
        </main>
      </div>

      {scanModal && (
        <DeviceScanModal
          onClose={() => setScanModal(false)}
          onDevicesFound={(n) => toast("success", "Scan Complete", `Found ${n} live devices`)}
        />
      )}

      <style>{`
        @keyframes ping { 75%,100%{transform:scale(2);opacity:0} }
        ::-webkit-scrollbar{width:5px;height:5px}
        ::-webkit-scrollbar-track{background:${T.bg}}
        ::-webkit-scrollbar-thumb{background:${T.border};border-radius:4px}
        ::-webkit-scrollbar-thumb:hover{background:${T.muted}}
      `}</style>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  DASHBOARD PAGE — stat cards + alert feed
// ─────────────────────────────────────────────────────────────
function DashboardPage({ deviceSummary, alertSummary, recentAlerts }) {
  const ds = deviceSummary || {};
  const as = alertSummary  || {};

  const STATS = [
    { label: "Total Devices",  value: ds.total   ?? "—", sub: `${ds.online ?? 0} online`,   color: T.accent,    icon: "M9 3H7a2 2 0 0 0-2 2v2M9 3h6M15 3h2a2 2 0 0 1 2 2v2M21 9v6M21 15v2a2 2 0 0 1-2 2h-2M15 21H9M9 21H7a2 2 0 0 1-2-2v-2M3 15V9M9 9h6v6H9z" },
    { label: "Active Alerts",  value: ds.error    ?? "—", sub: "need attention",              color: T.red,       icon: "M10.29 3.86L1.82 18a2 2 0 0 0 1.71 3h16.94a2 2 0 0 0 1.71-3L13.71 3.86a2 2 0 0 0-3.42 0zM12 9v4M12 17h.01" },
    { label: "Offline Devices",value: ds.offline  ?? "—", sub: "unreachable",                color: T.yellow,    icon: "M18.36 6.64a9 9 0 1 1-12.73 0M12 2v10" },
    { label: "Critical Alerts",value: as?.summary?.filter?.(s => s.severity === "critical")?.reduce?.((a, b) => a + b.count, 0) ?? "—",
      sub: "immediate action",                             color: T.accentAlt, icon: "M13 2L3 14h9l-1 8 10-12h-9l1-8z" },
  ];

  const SEV_COLOR = { critical: T.red, high: T.accentAlt, medium: T.yellow, low: T.green, info: T.accent };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 24 }}>
      {/* Stat grid */}
      <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 16 }}>
        {STATS.map((s, i) => (
          <div key={i} style={{ background: T.bgCard, border: `1px solid ${T.border}`,
            borderRadius: 12, padding: "18px 20px", position: "relative", overflow: "hidden",
            borderTop: `2px solid ${s.color}` }}>
            <div style={{ position: "absolute", inset: 0,
              background: `radial-gradient(ellipse at top right, ${s.color}10, transparent 70%)`,
              pointerEvents: "none" }}/>
            <div style={{ display: "flex", justifyContent: "space-between", alignItems: "flex-start", marginBottom: 10 }}>
              <span style={{ fontSize: 10, color: T.muted, fontFamily: "'Space Mono',monospace",
                letterSpacing: 2, textTransform: "uppercase" }}>{s.label}</span>
              <div style={{ padding: 6, borderRadius: 8, background: `${s.color}18`, border: `1px solid ${s.color}30` }}>
                <Icon d={s.icon} size={14} color={s.color}/>
              </div>
            </div>
            <div style={{ fontSize: 32, fontWeight: 800, color: s.color,
              fontFamily: "'Space Mono',monospace" }}>{s.value}</div>
            <div style={{ fontSize: 11, color: T.muted, marginTop: 4 }}>{s.sub}</div>
          </div>
        ))}
      </div>

      {/* Recent critical alerts */}
      <div style={{ background: T.bgCard, border: `1px solid ${T.border}`, borderRadius: 14 }}>
        <div style={{ padding: "14px 18px", borderBottom: `1px solid ${T.border}`,
          background: `linear-gradient(90deg,${T.red}10,transparent)` }}>
          <span style={{ fontFamily: "'Space Mono',monospace", fontSize: 11, color: T.red,
            letterSpacing: 2, textTransform: "uppercase", fontWeight: 700 }}>Recent Critical Alerts</span>
        </div>
        <div style={{ padding: "14px 18px" }}>
          {recentAlerts.length === 0 ? (
            <div style={{ textAlign: "center", padding: 24, color: T.green,
              fontFamily: "'Space Mono',monospace", fontSize: 12 }}>
              ✓ ALL CLEAR — NO CRITICAL ALERTS
            </div>
          ) : recentAlerts.map((a) => {
            const c = SEV_COLOR[a.severity] || T.muted;
            return (
              <div key={a.id} style={{ display: "flex", gap: 12, alignItems: "center",
                padding: "10px 12px", borderRadius: 8, marginBottom: 6,
                background: `${c}08`, borderLeft: `2px solid ${c}` }}>
                <div style={{ width: 6, height: 6, borderRadius: "50%", background: c, flexShrink: 0 }}/>
                <div style={{ flex: 1, fontSize: 13, color: T.text }}>{a.title}</div>
                <div style={{ fontSize: 10, color: c, fontFamily: "'Space Mono',monospace",
                  textTransform: "uppercase" }}>{a.severity}</div>
                <div style={{ fontSize: 10, color: T.muted, fontFamily: "'Space Mono',monospace" }}>
                  {new Date(a.created_at).toLocaleTimeString()}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  PLACEHOLDER for Devices / Alerts / Surveillance
// ─────────────────────────────────────────────────────────────
function PlaceholderPage({ name }) {
  return (
    <div style={{ display: "flex", flexDirection: "column", alignItems: "center",
      justifyContent: "center", minHeight: "60vh", gap: 16 }}>
      <div style={{ fontSize: 48, opacity: 0.3 }}>🔒</div>
      <div style={{ fontSize: 22, fontWeight: 800, color: T.text, textTransform: "capitalize" }}>
        {name} Module
      </div>
      <div style={{ fontSize: 13, color: T.muted, maxWidth: 400, textAlign: "center" }}>
        Connect your existing GRT dashboard panels for <strong>{name}</strong> here
        by importing them and adding them as a page case in the router.
      </div>
      <div style={{ padding: "8px 18px", borderRadius: 8, background: T.bgPanel,
        border: `1px solid ${T.border}`, fontSize: 11, color: T.accent,
        fontFamily: "'Space Mono',monospace" }}>
        IMPORT YOUR EXISTING COMPONENT →
      </div>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  ROOT — provider stack
// ─────────────────────────────────────────────────────────────
function AppInner() {
  const { user, loading } = useAuth();

  if (loading) {
    return (
      <div style={{ minHeight: "100vh", background: T.bg, display: "flex",
        alignItems: "center", justifyContent: "center" }}>
        <div style={{ fontFamily: "'Space Mono',monospace", color: T.accent,
          fontSize: 12, letterSpacing: 2, animation: "pulse 1.5s ease infinite" }}>
          INITIALISING GRT NEXUS...
        </div>
        <style>{`@keyframes pulse{0%,100%{opacity:1}50%{opacity:0.4}}`}</style>
      </div>
    );
  }

  return user ? <DashboardShell /> : <LoginPage />;
}

export default function App() {
  return (
    <AuthProvider>
      <NotificationProvider>
        <AppInner />
      </NotificationProvider>
    </AuthProvider>
  );
}
