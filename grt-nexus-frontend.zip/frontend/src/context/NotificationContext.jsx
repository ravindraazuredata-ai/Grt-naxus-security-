// src/context/NotificationContext.jsx
import { createContext, useContext, useState, useCallback, useRef, useEffect } from "react";
import { notifications as notifAPI } from "../services/api";

const NotifContext = createContext(null);

const THEME = {
  bg: "#0D1220", border: "#1E2D45", accent: "#0EA5E9",
  green: "#22D3A5", red: "#EF4444", yellow: "#FBBF24",
  accentAlt: "#F97316", text: "#E2EAF4", muted: "#64748B",
};

// ── Toast colours by type ─────────────────────────────────────
const TYPE_COLOR = {
  info:    THEME.accent,
  success: THEME.green,
  warning: THEME.yellow,
  error:   THEME.red,
  alert:   THEME.accentAlt,
};

// ── Single Toast component ────────────────────────────────────
function Toast({ id, type, title, message, onDismiss }) {
  const color = TYPE_COLOR[type] || THEME.accent;
  const [visible, setVisible] = useState(false);

  useEffect(() => {
    requestAnimationFrame(() => setVisible(true));
    const t = setTimeout(() => { setVisible(false); setTimeout(() => onDismiss(id), 400); }, 5000);
    return () => clearTimeout(t);
  }, []);

  return (
    <div style={{
      display: "flex", gap: 12, alignItems: "flex-start",
      background: THEME.bg, border: `1px solid ${color}55`,
      borderLeft: `3px solid ${color}`, borderRadius: 10,
      padding: "12px 16px", minWidth: 280, maxWidth: 380,
      boxShadow: `0 8px 32px rgba(0,0,0,0.5), 0 0 16px ${color}20`,
      transform: visible ? "translateX(0)" : "translateX(120%)",
      opacity: visible ? 1 : 0,
      transition: "transform 0.35s cubic-bezier(0.34,1.56,0.64,1), opacity 0.35s ease",
    }}>
      <div style={{ width: 8, height: 8, borderRadius: "50%", background: color, marginTop: 5, flexShrink: 0,
        boxShadow: `0 0 8px ${color}` }}/>
      <div style={{ flex: 1 }}>
        <div style={{ fontSize: 12, fontWeight: 700, color, fontFamily: "'Space Mono',monospace",
          letterSpacing: 1, textTransform: "uppercase" }}>{title}</div>
        <div style={{ fontSize: 12, color: THEME.text, marginTop: 3, lineHeight: 1.5 }}>{message}</div>
      </div>
      <button onClick={() => onDismiss(id)} style={{
        background: "none", border: "none", color: THEME.muted,
        cursor: "pointer", fontSize: 16, lineHeight: 1, padding: 0,
        flexShrink: 0,
      }}>×</button>
    </div>
  );
}

// ── Toast container ───────────────────────────────────────────
function ToastContainer({ toasts, onDismiss }) {
  return (
    <div style={{
      position: "fixed", top: 24, right: 24, zIndex: 9999,
      display: "flex", flexDirection: "column", gap: 10,
      pointerEvents: "none",
    }}>
      {toasts.map((t) => (
        <div key={t.id} style={{ pointerEvents: "all" }}>
          <Toast {...t} onDismiss={onDismiss} />
        </div>
      ))}
    </div>
  );
}

// ── Provider ──────────────────────────────────────────────────
export function NotificationProvider({ children }) {
  const [toasts, setToasts]       = useState([]);
  const [unreadCount, setUnreadCount] = useState(0);
  const [inbox, setInbox]         = useState([]);
  const counter = useRef(0);

  // Fetch unread count on mount
  useEffect(() => {
    notifAPI.count().then(setUnreadCount).catch(() => {});
    notifAPI.list({ limit: 10, unread_only: true })
      .then((d) => setInbox(d.notifications || []))
      .catch(() => {});
  }, []);

  const toast = useCallback((type, title, message) => {
    const id = ++counter.current;
    setToasts((prev) => [...prev.slice(-4), { id, type, title, message }]);
  }, []);

  const dismiss = useCallback((id) => {
    setToasts((prev) => prev.filter((t) => t.id !== id));
  }, []);

  // Called by WebSocket handler when notification:new arrives
  const pushNotification = useCallback((notif) => {
    setUnreadCount((n) => n + 1);
    setInbox((prev) => [notif, ...prev.slice(0, 9)]);
    toast(notif.type || "info", notif.title, notif.message);
  }, [toast]);

  const markRead = useCallback(async (id) => {
    await notifAPI.markRead(id);
    setInbox((prev) => prev.map((n) => n.id === id ? { ...n, is_read: true } : n));
    setUnreadCount((c) => Math.max(0, c - 1));
  }, []);

  const markAllRead = useCallback(async () => {
    await notifAPI.markAllRead();
    setInbox((prev) => prev.map((n) => ({ ...n, is_read: true })));
    setUnreadCount(0);
  }, []);

  return (
    <NotifContext.Provider value={{
      toast, pushNotification, markRead, markAllRead,
      unreadCount, inbox,
    }}>
      {children}
      <ToastContainer toasts={toasts} onDismiss={dismiss} />
    </NotifContext.Provider>
  );
}

export const useNotifications = () => {
  const ctx = useContext(NotifContext);
  if (!ctx) throw new Error("useNotifications must be inside <NotificationProvider>");
  return ctx;
};
