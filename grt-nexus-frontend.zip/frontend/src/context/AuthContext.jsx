// src/context/AuthContext.jsx
import { createContext, useContext, useState, useEffect, useCallback } from "react";
import { auth } from "../services/api";

const AuthContext = createContext(null);

// Session timeout — 8 hours (matches JWT expiry)
const SESSION_MS = 8 * 60 * 60 * 1000;

export function AuthProvider({ children }) {
  const [user, setUser]       = useState(null);
  const [loading, setLoading] = useState(true);
  const [sessionExp, setSessionExp] = useState(null);

  // ── Restore session on mount ───────────────────────────────
  useEffect(() => {
    const stored = auth.currentUser();
    if (stored && auth.isAuthenticated()) {
      setUser(stored);
      resetSessionTimer();
    }
    setLoading(false);
  }, []);

  // ── Activity-based session extension ──────────────────────
  const resetSessionTimer = useCallback(() => {
    const exp = Date.now() + SESSION_MS;
    setSessionExp(exp);
    localStorage.setItem("grt_session_exp", exp);
  }, []);

  useEffect(() => {
    if (!user) return;
    const events = ["mousemove", "keydown", "click", "touchstart"];
    const handler = () => resetSessionTimer();
    events.forEach((e) => window.addEventListener(e, handler, { passive: true }));

    // Check expiry every minute
    const check = setInterval(() => {
      const exp = parseInt(localStorage.getItem("grt_session_exp"), 10);
      if (exp && Date.now() > exp) logout();
    }, 60_000);

    return () => {
      events.forEach((e) => window.removeEventListener(e, handler));
      clearInterval(check);
    };
  }, [user, resetSessionTimer]);

  // ── Login ──────────────────────────────────────────────────
  const login = useCallback(async (email, password) => {
    const u = await auth.login(email, password);
    setUser(u);
    resetSessionTimer();
    return u;
  }, [resetSessionTimer]);

  // ── Logout ─────────────────────────────────────────────────
  const logout = useCallback(async () => {
    await auth.logout();
    setUser(null);
    setSessionExp(null);
    localStorage.removeItem("grt_session_exp");
  }, []);

  // ── Session time remaining (ms) ───────────────────────────
  const sessionRemaining = sessionExp ? Math.max(0, sessionExp - Date.now()) : 0;
  const sessionPct = Math.round((sessionRemaining / SESSION_MS) * 100);

  return (
    <AuthContext.Provider value={{
      user, loading,
      login, logout,
      sessionRemaining, sessionPct,
      isAdmin:    user?.role === "admin",
      isOperator: ["admin", "operator"].includes(user?.role),
    }}>
      {children}
    </AuthContext.Provider>
  );
}

export const useAuth = () => {
  const ctx = useContext(AuthContext);
  if (!ctx) throw new Error("useAuth must be used inside <AuthProvider>");
  return ctx;
};
