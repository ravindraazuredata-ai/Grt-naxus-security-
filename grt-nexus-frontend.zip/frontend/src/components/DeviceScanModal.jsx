// src/components/DeviceScanModal.jsx
import { useState, useEffect } from "react";
import { devices as devAPI } from "../services/api";
import { useWebSocket, EVENT_TYPES } from "../hooks/useWebSocket";

const T = {
  bg: "#070B14", bgCard: "#0D1220", bgPanel: "#101828",
  border: "#1E2D45", accent: "#0EA5E9", accentAlt: "#F97316",
  green: "#22D3A5", red: "#EF4444", yellow: "#FBBF24", purple: "#A78BFA",
  text: "#E2EAF4", muted: "#64748B",
};

export default function DeviceScanModal({ onClose, onDevicesFound }) {
  const [subnet, setSubnet] = useState(import.meta.env.VITE_SUBNET || "192.168.1");
  const [scanning, setScanning]   = useState(false);
  const [progress, setProgress]   = useState(0);
  const [found, setFound]         = useState([]);
  const [complete, setComplete]   = useState(false);

  const { connected } = useWebSocket({
    [EVENT_TYPES.SCAN_PROGRESS]: (data) => {
      setProgress(data.pct || 0);
    },
    [EVENT_TYPES.DEVICE_DISCOVERED]: (data) => {
      setFound((prev) => [...prev, data.ip_address]);
    },
    [EVENT_TYPES.SCAN_COMPLETE]: (data) => {
      setScanning(false);
      setComplete(true);
      setProgress(100);
      if (onDevicesFound) onDevicesFound(data.total_alive);
    },
  });

  const startScan = async () => {
    setFound([]);
    setProgress(0);
    setComplete(false);
    setScanning(true);
    try {
      await devAPI.scan(subnet);
    } catch (e) {
      setScanning(false);
      alert("Scan failed: " + e.message);
    }
  };

  const progressColor = progress > 75 ? T.green : progress > 40 ? T.accent : T.accentAlt;

  return (
    <div style={{ position: "fixed", inset: 0, zIndex: 2000,
      background: "rgba(7,11,20,0.9)", display: "flex",
      alignItems: "center", justifyContent: "center" }}>
      <div style={{ background: T.bgCard, border: `1px solid ${T.border}`,
        borderRadius: 18, padding: "28px 32px", width: 480, maxWidth: "90vw",
        boxShadow: `0 24px 64px rgba(0,0,0,0.6), 0 0 32px ${T.accent}18` }}>

        {/* Title */}
        <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center",
          marginBottom: 24 }}>
          <div>
            <div style={{ fontFamily: "'Space Mono',monospace", fontSize: 11, color: T.accent,
              letterSpacing: 2, textTransform: "uppercase", marginBottom: 4 }}>NETWORK DISCOVERY</div>
            <div style={{ fontSize: 18, fontWeight: 800, color: T.text }}>Device Scanner</div>
          </div>
          <button onClick={onClose} style={{ background: "none", border: "none",
            color: T.muted, cursor: "pointer", fontSize: 20 }}>×</button>
        </div>

        {/* Subnet input */}
        <div style={{ marginBottom: 20 }}>
          <label style={{ fontSize: 11, color: T.muted, fontFamily: "'Space Mono',monospace",
            letterSpacing: 1, textTransform: "uppercase", display: "block", marginBottom: 6 }}>
            Subnet Range
          </label>
          <div style={{ display: "flex", gap: 10, alignItems: "center" }}>
            <input value={subnet} onChange={(e) => setSubnet(e.target.value)}
              disabled={scanning}
              style={{ flex: 1, background: T.bgPanel, border: `1px solid ${T.border}`,
                borderRadius: 8, padding: "9px 12px", color: T.text, fontSize: 13,
                fontFamily: "'Space Mono',monospace", outline: "none" }}
              placeholder="e.g. 192.168.1"/>
            <span style={{ fontSize: 13, color: T.muted, fontFamily: "'Space Mono',monospace" }}>
              .1–.254
            </span>
          </div>
        </div>

        {/* WS status */}
        <div style={{ display: "flex", alignItems: "center", gap: 6, marginBottom: 20 }}>
          <div style={{ width: 6, height: 6, borderRadius: "50%",
            background: connected ? T.green : T.red,
            boxShadow: connected ? `0 0 6px ${T.green}` : "none" }}/>
          <span style={{ fontSize: 10, color: T.muted, fontFamily: "'Space Mono',monospace" }}>
            {connected ? "WS CONNECTED — live results enabled" : "WS OFFLINE — results may be delayed"}
          </span>
        </div>

        {/* Progress bar */}
        {(scanning || complete) && (
          <div style={{ marginBottom: 20 }}>
            <div style={{ display: "flex", justifyContent: "space-between",
              marginBottom: 6, fontSize: 11, fontFamily: "'Space Mono',monospace" }}>
              <span style={{ color: T.muted }}>{complete ? "SCAN COMPLETE" : `SCANNING... ${subnet}.x`}</span>
              <span style={{ color: progressColor }}>{progress}%</span>
            </div>
            <div style={{ height: 6, background: T.bgPanel, borderRadius: 3, overflow: "hidden" }}>
              <div style={{
                height: "100%", width: `${progress}%`, borderRadius: 3,
                background: `linear-gradient(90deg, ${T.accent}, ${progressColor})`,
                transition: "width 0.5s ease",
                boxShadow: `0 0 8px ${progressColor}`,
              }}/>
            </div>
          </div>
        )}

        {/* Discovered devices */}
        {found.length > 0 && (
          <div style={{ marginBottom: 20, background: T.bgPanel, border: `1px solid ${T.border}`,
            borderRadius: 10, maxHeight: 160, overflowY: "auto", padding: "10px 14px" }}>
            <div style={{ fontSize: 10, color: T.muted, fontFamily: "'Space Mono',monospace",
              letterSpacing: 1, marginBottom: 8 }}>DISCOVERED ({found.length})</div>
            {found.map((ip) => (
              <div key={ip} style={{ fontSize: 12, color: T.green, fontFamily: "'Space Mono',monospace",
                padding: "2px 0", display: "flex", alignItems: "center", gap: 8 }}>
                <div style={{ width: 5, height: 5, borderRadius: "50%", background: T.green,
                  flexShrink: 0 }}/>
                {ip}
              </div>
            ))}
          </div>
        )}

        {/* Complete summary */}
        {complete && (
          <div style={{ marginBottom: 20, padding: "12px 16px", borderRadius: 10,
            background: `${T.green}12`, border: `1px solid ${T.green}30`,
            display: "flex", alignItems: "center", gap: 12 }}>
            <span style={{ fontSize: 24 }}>✓</span>
            <div>
              <div style={{ fontSize: 13, fontWeight: 700, color: T.green }}>
                Scan Complete — {found.length} device{found.length !== 1 ? "s" : ""} found
              </div>
              <div style={{ fontSize: 11, color: T.muted, marginTop: 2 }}>
                New devices have been flagged in the device registry.
              </div>
            </div>
          </div>
        )}

        {/* Buttons */}
        <div style={{ display: "flex", gap: 10 }}>
          <button onClick={startScan} disabled={scanning || !subnet.trim()}
            style={{ flex: 1, background: scanning ? T.bgPanel : T.accent,
              border: `1px solid ${scanning ? T.border : T.accent}`,
              borderRadius: 10, padding: "11px", color: scanning ? T.muted : "#fff",
              fontFamily: "'Space Mono',monospace", fontSize: 12, cursor: scanning ? "not-allowed" : "pointer",
              letterSpacing: 1, fontWeight: 700, display: "flex", alignItems: "center",
              justifyContent: "center", gap: 8 }}>
            {scanning && (
              <div style={{ width: 12, height: 12, border: `2px solid ${T.muted}`,
                borderTopColor: T.accent, borderRadius: "50%",
                animation: "spin 0.8s linear infinite" }}/>
            )}
            {scanning ? "SCANNING..." : complete ? "SCAN AGAIN" : "START SCAN"}
          </button>
          <button onClick={onClose} style={{ padding: "11px 18px",
            background: "none", border: `1px solid ${T.border}`, borderRadius: 10,
            color: T.muted, fontFamily: "'Space Mono',monospace", fontSize: 12, cursor: "pointer" }}>
            CLOSE
          </button>
        </div>
      </div>

      <style>{`@keyframes spin{to{transform:rotate(360deg)}}`}</style>
    </div>
  );
}
