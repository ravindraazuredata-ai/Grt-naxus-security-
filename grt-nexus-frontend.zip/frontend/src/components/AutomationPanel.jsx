// src/components/AutomationPanel.jsx
import { useState, useEffect, useCallback } from "react";
import { automation as automationAPI } from "../services/api";
import { useNotifications } from "../context/NotificationContext";

const T = {
  bg: "#070B14", bgCard: "#0D1220", bgPanel: "#101828",
  border: "#1E2D45", accent: "#0EA5E9", accentAlt: "#F97316",
  green: "#22D3A5", red: "#EF4444", yellow: "#FBBF24", purple: "#A78BFA",
  text: "#E2EAF4", muted: "#64748B",
};

const TRIGGER_COLORS = {
  device_offline:       T.red,
  alert_severity:       T.accentAlt,
  schedule:             T.accent,
  device_status_change: T.yellow,
  alert_count:          T.purple,
};

const ACTION_COLORS = {
  send_notification: T.green,
  send_email:        T.accent,
  create_alert:      T.red,
  webhook:           T.purple,
  disable_device:    T.yellow,
};

function RuleRow({ rule, onToggle, onTest, onDelete }) {
  const [testing, setTesting] = useState(false);
  const tc = TRIGGER_COLORS[rule.trigger_type] || T.muted;
  const ac = ACTION_COLORS[rule.action_type]   || T.muted;

  const handleTest = async () => {
    setTesting(true);
    try { await onTest(rule.id); } finally { setTesting(false); }
  };

  return (
    <div style={{
      background: T.bgPanel, border: `1px solid ${T.border}`, borderRadius: 10,
      padding: "14px 16px", display: "flex", gap: 14, alignItems: "center",
      borderLeft: `3px solid ${rule.is_active ? T.green : T.muted}`,
    }}>
      {/* Toggle */}
      <button onClick={() => onToggle(rule.id)} title={rule.is_active ? "Disable" : "Enable"} style={{
        width: 34, height: 20, borderRadius: 10, border: "none", cursor: "pointer",
        background: rule.is_active ? T.green : T.border,
        position: "relative", flexShrink: 0, transition: "background 0.2s",
      }}>
        <div style={{
          position: "absolute", top: 3, left: rule.is_active ? 16 : 3,
          width: 14, height: 14, borderRadius: "50%", background: "#fff",
          transition: "left 0.2s",
        }}/>
      </button>

      {/* Rule info */}
      <div style={{ flex: 1, minWidth: 0 }}>
        <div style={{ fontSize: 13, fontWeight: 700, color: T.text,
          whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
          {rule.name}
        </div>
        <div style={{ display: "flex", gap: 8, marginTop: 5, flexWrap: "wrap" }}>
          <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 4,
            background: `${tc}18`, border: `1px solid ${tc}30`, color: tc,
            fontFamily: "'Space Mono',monospace" }}>
            ⚡ {rule.trigger_type}
          </span>
          <span style={{ fontSize: 10, padding: "2px 8px", borderRadius: 4,
            background: `${ac}18`, border: `1px solid ${ac}30`, color: ac,
            fontFamily: "'Space Mono',monospace" }}>
            → {rule.action_type}
          </span>
        </div>
      </div>

      {/* Stats */}
      <div style={{ textAlign: "right", flexShrink: 0 }}>
        <div style={{ fontSize: 12, color: T.muted, fontFamily: "'Space Mono',monospace" }}>
          {rule.trigger_count} runs
        </div>
        {rule.last_triggered && (
          <div style={{ fontSize: 10, color: T.muted, marginTop: 2 }}>
            {new Date(rule.last_triggered).toLocaleDateString()}
          </div>
        )}
      </div>

      {/* Actions */}
      <div style={{ display: "flex", gap: 6, flexShrink: 0 }}>
        <button onClick={handleTest} disabled={testing} style={{
          background: "none", border: `1px solid ${T.accent}40`,
          borderRadius: 6, padding: "4px 10px", fontSize: 10, color: T.accent,
          fontFamily: "'Space Mono',monospace", cursor: "pointer",
          opacity: testing ? 0.5 : 1,
        }}>{testing ? "..." : "TEST"}</button>
        <button onClick={() => onDelete(rule.id)} style={{
          background: "none", border: `1px solid ${T.red}40`,
          borderRadius: 6, padding: "4px 10px", fontSize: 10, color: T.red,
          fontFamily: "'Space Mono',monospace", cursor: "pointer",
        }}>DEL</button>
      </div>
    </div>
  );
}

// ── New Rule Form ─────────────────────────────────────────────
function NewRuleForm({ meta, onCreated, onCancel }) {
  const [form, setForm] = useState({
    name: "", trigger_type: "", action_type: "",
    trigger_config: "{}", action_config: "{}",
  });
  const [saving, setSaving] = useState(false);
  const [err, setErr]       = useState("");

  const set = (k, v) => setForm((f) => ({ ...f, [k]: v }));

  const handleSubmit = async () => {
    setErr("");
    try {
      const body = {
        ...form,
        trigger_config: JSON.parse(form.trigger_config),
        action_config:  JSON.parse(form.action_config),
      };
      setSaving(true);
      const rule = await automationAPI.create(body);
      onCreated(rule);
    } catch (e) {
      setErr(e.message || "Invalid JSON in config fields");
    } finally {
      setSaving(false);
    }
  };

  const inputStyle = {
    width: "100%", background: T.bgPanel, border: `1px solid ${T.border}`,
    borderRadius: 8, padding: "9px 12px", color: T.text, fontSize: 12,
    fontFamily: "'Space Mono',monospace", outline: "none", boxSizing: "border-box",
  };

  const selectStyle = { ...inputStyle };

  return (
    <div style={{ background: T.bgCard, border: `1px solid ${T.border}`, borderRadius: 12,
      padding: 20, display: "flex", flexDirection: "column", gap: 12 }}>
      <div style={{ fontSize: 12, color: T.accent, fontFamily: "'Space Mono',monospace",
        letterSpacing: 2, textTransform: "uppercase" }}>NEW AUTOMATION RULE</div>

      <input placeholder="Rule name" value={form.name} onChange={(e) => set("name", e.target.value)}
        style={inputStyle}/>

      <div style={{ display: "grid", gridTemplateColumns: "1fr 1fr", gap: 10 }}>
        <select value={form.trigger_type} onChange={(e) => set("trigger_type", e.target.value)}
          style={selectStyle}>
          <option value="">— Trigger Type —</option>
          {(meta?.trigger_types || []).map((t) => <option key={t} value={t}>{t}</option>)}
        </select>
        <select value={form.action_type} onChange={(e) => set("action_type", e.target.value)}
          style={selectStyle}>
          <option value="">— Action Type —</option>
          {(meta?.action_types || []).map((a) => <option key={a} value={a}>{a}</option>)}
        </select>
      </div>

      {/* Config hints */}
      {form.trigger_type && (
        <div style={{ fontSize: 10, color: T.muted, fontFamily: "'Space Mono',monospace",
          padding: "6px 10px", background: T.bgPanel, borderRadius: 6, border: `1px solid ${T.border}` }}>
          💡 {meta?.trigger_descriptions?.[form.trigger_type] || form.trigger_type}
        </div>
      )}

      <textarea placeholder='Trigger Config JSON — e.g. {"severity":"critical"}'
        value={form.trigger_config} rows={3}
        onChange={(e) => set("trigger_config", e.target.value)}
        style={{ ...inputStyle, resize: "vertical", lineHeight: 1.5 }}/>

      <textarea placeholder='Action Config JSON — e.g. {"to":"admin@co.com","subject":"Alert!"}'
        value={form.action_config} rows={3}
        onChange={(e) => set("action_config", e.target.value)}
        style={{ ...inputStyle, resize: "vertical", lineHeight: 1.5 }}/>

      {err && <div style={{ fontSize: 11, color: T.red, fontFamily: "'Space Mono',monospace" }}>⚠ {err}</div>}

      <div style={{ display: "flex", gap: 10 }}>
        <button onClick={handleSubmit} disabled={saving || !form.name || !form.trigger_type || !form.action_type}
          style={{ flex: 1, background: T.accent, border: "none", borderRadius: 8,
            padding: "10px", color: "#fff", fontFamily: "'Space Mono',monospace",
            fontSize: 12, cursor: "pointer", opacity: saving ? 0.6 : 1, letterSpacing: 1 }}>
          {saving ? "CREATING..." : "CREATE RULE"}
        </button>
        <button onClick={onCancel} style={{ padding: "10px 18px", background: "none",
          border: `1px solid ${T.border}`, borderRadius: 8, color: T.muted,
          fontFamily: "'Space Mono',monospace", fontSize: 12, cursor: "pointer" }}>
          CANCEL
        </button>
      </div>
    </div>
  );
}

// ── Main Panel ────────────────────────────────────────────────
export default function AutomationPanel() {
  const [rules, setRules]   = useState([]);
  const [meta, setMeta]     = useState(null);
  const [loading, setLoading] = useState(true);
  const [showForm, setShowForm] = useState(false);
  const { toast } = useNotifications();

  const load = useCallback(async () => {
    try {
      const [r, m] = await Promise.all([automationAPI.rules(), automationAPI.meta()]);
      setRules(r.rules || []);
      setMeta(m);
    } catch (e) {
      toast("error", "Load Failed", e.message);
    } finally {
      setLoading(false);
    }
  }, []);

  useEffect(() => { load(); }, [load]);

  const handleToggle = async (id) => {
    try {
      const updated = await automationAPI.toggle(id);
      setRules((prev) => prev.map((r) => r.id === id ? updated : r));
      toast("success", "Rule Updated", `Rule ${updated.is_active ? "enabled" : "disabled"}`);
    } catch (e) { toast("error", "Toggle Failed", e.message); }
  };

  const handleTest = async (id) => {
    try {
      await automationAPI.test(id, { source: "manual_test" });
      toast("success", "Test Complete", "Automation rule executed successfully");
    } catch (e) { toast("error", "Test Failed", e.message); }
  };

  const handleDelete = async (id) => {
    if (!confirm("Delete this automation rule?")) return;
    try {
      await automationAPI.delete(id);
      setRules((prev) => prev.filter((r) => r.id !== id));
      toast("success", "Rule Deleted", "Automation rule removed");
    } catch (e) { toast("error", "Delete Failed", e.message); }
  };

  const handleCreated = (rule) => {
    setRules((prev) => [rule, ...prev]);
    setShowForm(false);
    toast("success", "Rule Created", rule.name);
  };

  return (
    <div style={{ display: "flex", flexDirection: "column", gap: 12 }}>
      {/* Header */}
      <div style={{ display: "flex", justifyContent: "space-between", alignItems: "center" }}>
        <div>
          <div style={{ fontSize: 14, fontWeight: 700, color: T.text }}>Automation Rules</div>
          <div style={{ fontSize: 11, color: T.muted, fontFamily: "'Space Mono',monospace" }}>
            {rules.filter((r) => r.is_active).length} active / {rules.length} total
          </div>
        </div>
        <button onClick={() => setShowForm((s) => !s)} style={{
          background: showForm ? "none" : T.accent, border: `1px solid ${showForm ? T.border : T.accent}`,
          borderRadius: 8, padding: "7px 16px", color: showForm ? T.muted : "#fff",
          fontFamily: "'Space Mono',monospace", fontSize: 11, cursor: "pointer", letterSpacing: 1,
        }}>{showForm ? "CANCEL" : "+ NEW RULE"}</button>
      </div>

      {showForm && <NewRuleForm meta={meta} onCreated={handleCreated} onCancel={() => setShowForm(false)} />}

      {loading ? (
        <div style={{ textAlign: "center", padding: 40, color: T.muted,
          fontFamily: "'Space Mono',monospace", fontSize: 11 }}>LOADING RULES...</div>
      ) : rules.length === 0 ? (
        <div style={{ textAlign: "center", padding: 40, color: T.muted,
          fontFamily: "'Space Mono',monospace", fontSize: 11, background: T.bgPanel,
          borderRadius: 10, border: `1px solid ${T.border}` }}>NO AUTOMATION RULES CONFIGURED</div>
      ) : (
        <div style={{ display: "flex", flexDirection: "column", gap: 8 }}>
          {rules.map((r) => (
            <RuleRow key={r.id} rule={r} onToggle={handleToggle} onTest={handleTest} onDelete={handleDelete} />
          ))}
        </div>
      )}
    </div>
  );
}
