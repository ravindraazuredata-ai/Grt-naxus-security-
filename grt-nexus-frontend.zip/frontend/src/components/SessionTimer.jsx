// src/components/SessionTimer.jsx
import { useState, useEffect } from "react";
import { useAuth } from "../context/AuthContext";

const T = {
  bgPanel: "#101828", border: "#1E2D45", accent: "#0EA5E9",
  yellow: "#FBBF24", red: "#EF4444", green: "#22D3A5",
  muted: "#64748B", text: "#E2EAF4",
};

function fmtMs(ms) {
  const totalSec = Math.floor(ms / 1000);
  const h = Math.floor(totalSec / 3600);
  const m = Math.floor((totalSec % 3600) / 60);
  const s = totalSec % 60;
  if (h > 0) return `${h}h ${m.toString().padStart(2,"0")}m`;
  return `${m.toString().padStart(2,"0")}:${s.toString().padStart(2,"0")}`;
}

export default function SessionTimer() {
  const { sessionRemaining, sessionPct, logout } = useAuth();
  const [tick, setTick] = useState(0);
  const [warn, setWarn]   = useState(false);

  useEffect(() => {
    const id = setInterval(() => setTick((n) => n + 1), 1000);
    return () => clearInterval(id);
  }, []);

  const danger = sessionPct < 10;
  const color  = danger ? T.red : sessionPct < 25 ? T.yellow : T.green;

  // Flash warning once when under 5 min
  useEffect(() => {
    if (sessionRemaining < 5 * 60 * 1000 && !warn) setWarn(true);
  }, [sessionRemaining]);

  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10,
      background: T.bgPanel, border: `1px solid ${warn ? color : T.border}`,
      borderRadius: 8, padding: "6px 14px", transition: "border-color 0.3s",
      boxShadow: warn ? `0 0 10px ${color}30` : "none" }}>
      {/* Circular progress */}
      <svg width={24} height={24} style={{ transform: "rotate(-90deg)", flexShrink: 0 }}>
        <circle cx={12} cy={12} r={9} fill="none" stroke={T.border} strokeWidth={2.5}/>
        <circle cx={12} cy={12} r={9} fill="none" stroke={color} strokeWidth={2.5}
          strokeDasharray={`${(sessionPct / 100) * 2 * Math.PI * 9} ${2 * Math.PI * 9}`}
          style={{ transition: "stroke-dasharray 1s linear, stroke 0.3s" }}/>
      </svg>
      <div>
        <div style={{ fontSize: 10, color: T.muted, fontFamily: "'Space Mono',monospace",
          letterSpacing: 1, lineHeight: 1 }}>SESSION</div>
        <div style={{ fontSize: 13, color, fontFamily: "'Space Mono',monospace",
          fontWeight: 700, lineHeight: 1.3 }}>{fmtMs(sessionRemaining)}</div>
      </div>
      {warn && (
        <button onClick={logout} title="End session" style={{
          background: "none", border: `1px solid ${T.red}40`,
          borderRadius: 6, padding: "2px 8px", fontSize: 10, color: T.red,
          fontFamily: "'Space Mono',monospace", cursor: "pointer", letterSpacing: 1,
        }}>LOGOUT</button>
      )}
    </div>
  );
}
