// src/components/NotificationBell.jsx
import { useState, useRef, useEffect } from "react";
import { useNotifications } from "../context/NotificationContext";

const T = {
  bg: "#070B14", bgCard: "#0D1220", bgPanel: "#101828",
  border: "#1E2D45", accent: "#0EA5E9", accentAlt: "#F97316",
  green: "#22D3A5", red: "#EF4444", yellow: "#FBBF24",
  text: "#E2EAF4", muted: "#64748B",
};

const TYPE_COLOR = {
  info: T.accent, success: T.green, warning: T.yellow,
  error: T.red, alert: T.accentAlt,
};

function timeAgo(dateStr) {
  const diff = Date.now() - new Date(dateStr).getTime();
  const m = Math.floor(diff / 60000);
  if (m < 1) return "just now";
  if (m < 60) return `${m}m ago`;
  const h = Math.floor(m / 60);
  if (h < 24) return `${h}h ago`;
  return `${Math.floor(h / 24)}d ago`;
}

export default function NotificationBell() {
  const { unreadCount, inbox, markRead, markAllRead } = useNotifications();
  const [open, setOpen] = useState(false);
  const ref = useRef(null);

  useEffect(() => {
    const handler = (e) => { if (ref.current && !ref.current.contains(e.target)) setOpen(false); };
    document.addEventListener("mousedown", handler);
    return () => document.removeEventListener("mousedown", handler);
  }, []);

  const bellColor = unreadCount > 0 ? T.accentAlt : T.muted;

  return (
    <div ref={ref} style={{ position: "relative" }}>
      <button onClick={() => setOpen((o) => !o)} style={{
        position: "relative", background: "none", border: "none",
        cursor: "pointer", padding: 8, display: "flex", alignItems: "center",
      }}>
        {/* Bell icon */}
        <svg width={22} height={22} viewBox="0 0 24 24" fill="none"
          stroke={bellColor} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
          <path d="M18 8A6 6 0 0 0 6 8c0 7-3 9-3 9h18s-3-2-3-9M13.73 21a2 2 0 0 1-3.46 0"/>
        </svg>
        {unreadCount > 0 && (
          <span style={{
            position: "absolute", top: 4, right: 4,
            width: 16, height: 16, borderRadius: "50%",
            background: T.red, fontSize: 9, fontWeight: 700, color: "#fff",
            display: "flex", alignItems: "center", justifyContent: "center",
            fontFamily: "'Space Mono',monospace",
            boxShadow: `0 0 8px ${T.red}`,
            animation: "ping 1.5s cubic-bezier(0,0,0.2,1) infinite",
          }}>
            {unreadCount > 9 ? "9+" : unreadCount}
          </span>
        )}
      </button>

      {open && (
        <div style={{
          position: "absolute", right: 0, top: "calc(100% + 10px)",
          width: 340, background: T.bgCard, border: `1px solid ${T.border}`,
          borderRadius: 14, zIndex: 999, overflow: "hidden",
          boxShadow: `0 24px 48px rgba(0,0,0,0.5), 0 0 24px ${T.accent}18`,
        }}>
          {/* Header */}
          <div style={{ padding: "14px 18px", borderBottom: `1px solid ${T.border}`,
            display: "flex", justifyContent: "space-between", alignItems: "center",
            background: `linear-gradient(90deg, ${T.accent}08, transparent)` }}>
            <span style={{ fontFamily: "'Space Mono',monospace", fontSize: 11,
              color: T.accent, letterSpacing: 2, textTransform: "uppercase", fontWeight: 700 }}>
              Notifications {unreadCount > 0 && `(${unreadCount})`}
            </span>
            {unreadCount > 0 && (
              <button onClick={markAllRead} style={{
                background: "none", border: "none", fontSize: 10,
                color: T.muted, cursor: "pointer", fontFamily: "'Space Mono',monospace",
              }}>MARK ALL READ</button>
            )}
          </div>

          {/* Notification list */}
          <div style={{ maxHeight: 320, overflowY: "auto" }}>
            {inbox.length === 0 ? (
              <div style={{ padding: 32, textAlign: "center", color: T.muted,
                fontSize: 12, fontFamily: "'Space Mono',monospace" }}>
                NO NEW NOTIFICATIONS
              </div>
            ) : inbox.map((n) => {
              const c = TYPE_COLOR[n.type] || T.accent;
              return (
                <div key={n.id} onClick={() => markRead(n.id)} style={{
                  padding: "12px 16px", borderBottom: `1px solid ${T.border}10`,
                  cursor: "pointer", display: "flex", gap: 10, alignItems: "flex-start",
                  background: n.is_read ? "transparent" : `${c}06`,
                  transition: "background 0.15s",
                }}
                onMouseEnter={(e) => e.currentTarget.style.background = `${c}10`}
                onMouseLeave={(e) => e.currentTarget.style.background = n.is_read ? "transparent" : `${c}06`}>
                  <div style={{ width: 6, height: 6, borderRadius: "50%", background: c,
                    flexShrink: 0, marginTop: 5 }}/>
                  <div style={{ flex: 1, minWidth: 0 }}>
                    <div style={{ fontSize: 12, fontWeight: 600, color: T.text,
                      whiteSpace: "nowrap", overflow: "hidden", textOverflow: "ellipsis" }}>
                      {n.title}
                    </div>
                    <div style={{ fontSize: 11, color: T.muted, marginTop: 2, lineHeight: 1.4 }}>
                      {n.message}
                    </div>
                  </div>
                  <div style={{ fontSize: 9, color: T.muted, fontFamily: "'Space Mono',monospace",
                    flexShrink: 0, marginTop: 2 }}>
                    {timeAgo(n.created_at)}
                  </div>
                </div>
              );
            })}
          </div>

          {/* Footer */}
          <div style={{ padding: "10px 18px", borderTop: `1px solid ${T.border}`,
            textAlign: "center" }}>
            <button onClick={() => setOpen(false)} style={{
              background: "none", border: "none", fontSize: 11, color: T.muted,
              cursor: "pointer", fontFamily: "'Space Mono',monospace", letterSpacing: 1,
            }}>VIEW ALL NOTIFICATIONS →</button>
          </div>
        </div>
      )}
    </div>
  );
}
