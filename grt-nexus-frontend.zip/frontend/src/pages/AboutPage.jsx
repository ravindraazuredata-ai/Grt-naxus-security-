// src/pages/AboutPage.jsx
import { useState, useEffect, useRef } from "react";
import { system } from "../services/api";

// ── Theme (matches GRT dashboard) ────────────────────────────
const T = {
  bg: "#070B14", bgCard: "#0D1220", bgPanel: "#101828",
  border: "#1E2D45", accent: "#0EA5E9", accentAlt: "#F97316",
  green: "#22D3A5", red: "#EF4444", yellow: "#FBBF24", purple: "#A78BFA",
  text: "#E2EAF4", muted: "#64748B", glow: "rgba(14,165,233,0.15)",
};

const Icon = ({ d, size = 20, color = "currentColor" }) => (
  <svg width={size} height={size} viewBox="0 0 24 24" fill="none"
    stroke={color} strokeWidth={1.8} strokeLinecap="round" strokeLinejoin="round">
    <path d={d} />
  </svg>
);

// ── Animated counter ──────────────────────────────────────────
function Counter({ target, suffix = "", duration = 1800 }) {
  const [val, setVal] = useState(0);
  const ref = useRef(null);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => {
      if (!e.isIntersecting) return;
      obs.disconnect();
      const start = Date.now();
      const tick = () => {
        const p = Math.min((Date.now() - start) / duration, 1);
        setVal(Math.floor(p * target));
        if (p < 1) requestAnimationFrame(tick);
      };
      requestAnimationFrame(tick);
    }, { threshold: 0.3 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [target, duration]);
  return <span ref={ref}>{val.toLocaleString()}{suffix}</span>;
}

// ── Section title ─────────────────────────────────────────────
function SectionTitle({ label, title, accent = T.accent }) {
  return (
    <div style={{ textAlign: "center", marginBottom: 48 }}>
      <div style={{ fontFamily: "'Space Mono',monospace", fontSize: 11, color: accent,
        letterSpacing: 4, textTransform: "uppercase", marginBottom: 10 }}>{label}</div>
      <h2 style={{ fontSize: 32, fontWeight: 800, color: T.text, margin: 0, lineHeight: 1.2 }}>{title}</h2>
      <div style={{ width: 48, height: 2, background: `linear-gradient(90deg,transparent,${accent},transparent)`,
        margin: "16px auto 0" }}/>
    </div>
  );
}

// ── Feature card ──────────────────────────────────────────────
function FeatureCard({ icon, title, desc, color, delay = 0 }) {
  const [vis, setVis] = useState(false);
  const ref = useRef(null);
  useEffect(() => {
    const obs = new IntersectionObserver(([e]) => {
      if (e.isIntersecting) { setTimeout(() => setVis(true), delay); obs.disconnect(); }
    }, { threshold: 0.2 });
    if (ref.current) obs.observe(ref.current);
    return () => obs.disconnect();
  }, [delay]);

  return (
    <div ref={ref} style={{
      background: T.bgCard, border: `1px solid ${T.border}`, borderRadius: 16,
      padding: "28px 24px", position: "relative", overflow: "hidden",
      transform: vis ? "translateY(0)" : "translateY(32px)",
      opacity: vis ? 1 : 0, transition: "all 0.6s cubic-bezier(0.34,1.56,0.64,1)",
    }}>
      <div style={{ position: "absolute", inset: 0, background:
        `radial-gradient(ellipse at top right, ${color}10, transparent 60%)`, pointerEvents: "none" }}/>
      <div style={{ width: 48, height: 48, borderRadius: 12, background: `${color}18`,
        border: `1px solid ${color}30`, display: "flex", alignItems: "center",
        justifyContent: "center", marginBottom: 16 }}>
        <Icon d={icon} size={22} color={color} />
      </div>
      <div style={{ fontSize: 15, fontWeight: 700, color: T.text, marginBottom: 8 }}>{title}</div>
      <div style={{ fontSize: 13, color: T.muted, lineHeight: 1.6 }}>{desc}</div>
    </div>
  );
}

// ── Team member ───────────────────────────────────────────────
function TeamCard({ name, role, initials, color }) {
  return (
    <div style={{
      background: T.bgCard, border: `1px solid ${T.border}`, borderRadius: 14,
      padding: "24px 20px", textAlign: "center",
    }}>
      <div style={{
        width: 64, height: 64, borderRadius: "50%", background: `${color}22`,
        border: `2px solid ${color}`, display: "flex", alignItems: "center",
        justifyContent: "center", margin: "0 auto 14px",
        fontSize: 20, fontWeight: 800, color, fontFamily: "'Space Mono',monospace",
      }}>{initials}</div>
      <div style={{ fontSize: 14, fontWeight: 700, color: T.text }}>{name}</div>
      <div style={{ fontSize: 11, color: T.muted, marginTop: 4,
        fontFamily: "'Space Mono',monospace", letterSpacing: 1 }}>{role}</div>
    </div>
  );
}

// ── Status badge ──────────────────────────────────────────────
function StatusBadge({ label, ok }) {
  const c = ok ? T.green : T.red;
  return (
    <div style={{ display: "flex", alignItems: "center", gap: 10,
      background: T.bgPanel, border: `1px solid ${T.border}`,
      borderRadius: 8, padding: "10px 16px" }}>
      <div style={{ width: 8, height: 8, borderRadius: "50%", background: c,
        boxShadow: `0 0 6px ${c}` }}/>
      <span style={{ fontSize: 12, color: T.text, fontFamily: "'Space Mono',monospace" }}>{label}</span>
      <span style={{ fontSize: 10, color: c, marginLeft: "auto",
        fontFamily: "'Space Mono',monospace" }}>{ok ? "OPERATIONAL" : "DEGRADED"}</span>
    </div>
  );
}

// ─────────────────────────────────────────────────────────────
//  MAIN ABOUT PAGE
// ─────────────────────────────────────────────────────────────
export default function AboutPage() {
  const [health, setHealth] = useState(null);
  const [about, setAbout]   = useState(null);
  const [uptime, setUptime] = useState(0);

  useEffect(() => {
    system.health().then((d) => { setHealth(d); setUptime(d.uptime || 0); }).catch(() => {});
    system.about().then(setAbout).catch(() => {});
  }, []);

  const fmtUptime = (s) => {
    const h = Math.floor(s / 3600), m = Math.floor((s % 3600) / 60);
    return `${h}h ${m}m`;
  };

  const FEATURES = [
    { icon: "M15 10l4.553-2.069A1 1 0 0 1 21 8.87v6.26a1 1 0 0 1-1.447.939L15 14M3 8h12v8H3z", title: "AI Surveillance", color: T.accent,
      desc: "360° camera monitoring with motion detection, facial recognition zones, and real-time threat classification across all camera feeds." },
    { icon: "M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z", title: "Smart Alert Engine", color: T.red,
      desc: "Multi-tier alert system with configurable severity thresholds, auto-escalation policies, and instant multi-channel dispatch." },
    { icon: "M13 2L3 14h9l-1 8 10-12h-9l1-8z", title: "Automation Rules", color: T.accentAlt,
      desc: "Visual rule builder supporting 5 trigger types and 5 action types. Schedule-based, event-driven, and threshold-based automations." },
    { icon: "M9 3H7a2 2 0 0 0-2 2v2M9 3h6M15 3h2a2 2 0 0 1 2 2v2M21 9v6M21 15v2a2 2 0 0 1-2 2h-2M15 21H9M9 21H7a2 2 0 0 1-2-2v-2M3 15V9M9 9h6v6H9z", title: "Device Registry", color: T.purple,
      desc: "Unified device management for cameras, sensors, servers, IoT nodes. Automatic subnet discovery with live ping health checks." },
    { icon: "M22 12h-4l-3 9L9 3l-3 9H2", title: "Real-time Dashboard", color: T.green,
      desc: "WebSocket-powered live dashboard with threat scoring, sparkline trends, geo zone mapping, and interactive device status grid." },
    { icon: "M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8zM12 12m-3 0a3 3 0 1 0 6 0 3 3 0 0 0-6 0", title: "Multi-Factor Auth", color: T.yellow,
      desc: "Biometric scan simulation + 4-digit PIN with role-based access control (Admin / Operator / Viewer) and session timeout guards." },
    { icon: "M1 6v16l7-4 8 4 7-4V2l-7 4-8-4-7 4zM8 2v16M16 6v16", title: "Geo Zone Mapping", color: T.accent,
      desc: "Visual facility map with zone status overlay, camera placement markers, drone patrol tracking, and motion event heat zones." },
    { icon: "M12 22c0 0-8-6-8-12a8 8 0 0 1 16 0c0 6-8 12-8 12zm0-8a4 4 0 1 0 0-8 4 4 0 0 0 0 8z", title: "IoT Sensor Network", color: T.green,
      desc: "Environmental, motion, door/window, and gas sensors integrated into a unified alert pipeline with threshold-based automation triggers." },
  ];

  const STATS = [
    { label: "Devices Monitored", value: 2400, suffix: "+", color: T.accent },
    { label: "Alerts Handled / Day", value: 12000, suffix: "", color: T.accentAlt },
    { label: "Uptime SLA", value: 99, suffix: ".9%", color: T.green },
    { label: "Response Time", value: 120, suffix: "ms", color: T.purple },
  ];

  const TEAM = [
    { name: "GRT Security Core", role: "PLATFORM ARCHITECT", initials: "GC", color: T.accent },
    { name: "Automation Division", role: "RULE ENGINE TEAM", initials: "AD", color: T.accentAlt },
    { name: "Network Ops Centre", role: "24/7 MONITORING", initials: "NO", color: T.green },
    { name: "R&D Intelligence", role: "AI / ML DIVISION", initials: "RI", color: T.purple },
  ];

  const INTEGRATIONS = [
    "ONVIF Cameras", "RTSP Streams", "SNMP Devices", "MSSQL / SQL Server",
    "SMTP Email", "Webhook APIs", "Node.js Backend", "React Frontend",
  ];

  return (
    <div style={{ background: T.bg, minHeight: "100vh", color: T.text,
      fontFamily: "'Inter',system-ui,sans-serif" }}>

      {/* ── HERO ─────────────────────────────────────────────── */}
      <section style={{ position: "relative", padding: "100px 24px 80px", textAlign: "center",
        overflow: "hidden" }}>
        {/* Animated grid */}
        <div style={{ position: "absolute", inset: 0, overflow: "hidden", opacity: 0.04, pointerEvents: "none" }}>
          {Array.from({ length: 16 }).map((_, i) => (
            <div key={`h${i}`} style={{ position: "absolute", left: 0, right: 0, height: 1,
              top: `${i * 6.5}%`, background: `linear-gradient(90deg,transparent,${T.accent},transparent)` }}/>
          ))}
          {Array.from({ length: 20 }).map((_, i) => (
            <div key={`v${i}`} style={{ position: "absolute", top: 0, bottom: 0, width: 1,
              left: `${i * 5 + 5}%`, background: `linear-gradient(180deg,transparent,${T.accent},transparent)` }}/>
          ))}
        </div>
        {/* Glow orbs */}
        <div style={{ position: "absolute", top: "20%", left: "20%", width: 400, height: 400,
          borderRadius: "50%", background: `radial-gradient(circle,${T.accent}12,transparent 70%)`,
          filter: "blur(40px)", pointerEvents: "none" }}/>
        <div style={{ position: "absolute", bottom: "10%", right: "15%", width: 300, height: 300,
          borderRadius: "50%", background: `radial-gradient(circle,${T.accentAlt}10,transparent 70%)`,
          filter: "blur(40px)", pointerEvents: "none" }}/>

        <div style={{ position: "relative", maxWidth: 720, margin: "0 auto" }}>
          <div style={{ fontFamily: "'Space Mono',monospace", fontSize: 11, color: T.accent,
            letterSpacing: 5, textTransform: "uppercase", marginBottom: 16 }}>
            GRT ASSIST AUTOMATIONS & SECURITY PVT. LTD.
          </div>
          <h1 style={{ fontSize: "clamp(36px,6vw,64px)", fontWeight: 900, lineHeight: 1.1,
            margin: "0 0 20px", letterSpacing: -1 }}>
            <span style={{ color: T.text }}>GRT </span>
            <span style={{ background: `linear-gradient(135deg,${T.accent},${T.purple})`,
              WebkitBackgroundClip: "text", WebkitTextFillColor: "transparent" }}>NEXUS</span>
            <span style={{ color: T.text }}> SECURITY</span>
          </h1>
          <p style={{ fontSize: 17, color: T.muted, lineHeight: 1.7, margin: "0 0 40px",
            maxWidth: 540, marginLeft: "auto", marginRight: "auto" }}>
            Enterprise-grade unified security intelligence platform — combining
            AI surveillance, IoT device management, and intelligent automation
            into one real-time operations centre.
          </p>
          <div style={{ display: "flex", gap: 12, justifyContent: "center", flexWrap: "wrap" }}>
            {[
              { label: "View Dashboard", color: T.accent },
              { label: "Documentation →", color: "transparent", border: T.accent },
            ].map((b, i) => (
              <button key={i} style={{
                padding: "12px 28px", borderRadius: 10, fontSize: 13, fontWeight: 600,
                fontFamily: "'Space Mono',monospace", letterSpacing: 1, cursor: "pointer",
                background: b.border ? "transparent" : b.color,
                border: `1px solid ${b.border || b.color}`,
                color: b.border ? T.accent : "#fff",
                transition: "all 0.2s",
              }}
              onMouseEnter={(e) => { e.currentTarget.style.opacity = "0.8"; e.currentTarget.style.transform = "translateY(-2px)"; }}
              onMouseLeave={(e) => { e.currentTarget.style.opacity = "1"; e.currentTarget.style.transform = "none"; }}
              >{b.label}</button>
            ))}
          </div>
        </div>
      </section>

      {/* ── STAT STRIP ───────────────────────────────────────── */}
      <section style={{ padding: "0 24px 80px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto",
          display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 20 }}>
          {STATS.map((s, i) => (
            <div key={i} style={{ background: T.bgCard, border: `1px solid ${T.border}`,
              borderRadius: 14, padding: "28px 24px", textAlign: "center",
              borderTop: `2px solid ${s.color}` }}>
              <div style={{ fontSize: 40, fontWeight: 800, color: s.color,
                fontFamily: "'Space Mono',monospace" }}>
                <Counter target={s.value} suffix={s.suffix} />
              </div>
              <div style={{ fontSize: 12, color: T.muted, marginTop: 6,
                fontFamily: "'Space Mono',monospace", letterSpacing: 1, textTransform: "uppercase" }}>
                {s.label}
              </div>
            </div>
          ))}
        </div>
      </section>

      {/* ── FEATURES ─────────────────────────────────────────── */}
      <section style={{ padding: "0 24px 100px" }}>
        <div style={{ maxWidth: 1100, margin: "0 auto" }}>
          <SectionTitle label="Platform Capabilities" title="Everything You Need to Secure Operations" />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(280px,1fr))", gap: 20 }}>
            {FEATURES.map((f, i) => (
              <FeatureCard key={i} delay={i * 80} {...f} />
            ))}
          </div>
        </div>
      </section>

      {/* ── HOW IT WORKS ─────────────────────────────────────── */}
      <section style={{ padding: "0 24px 100px" }}>
        <div style={{ maxWidth: 900, margin: "0 auto" }}>
          <SectionTitle label="Architecture" title="How GRT Nexus Works" accent={T.accentAlt} />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(200px,1fr))", gap: 0 }}>
            {[
              { step: "01", label: "Detect", desc: "Devices, cameras & sensors stream events in real-time", color: T.accent },
              { step: "02", label: "Analyse", desc: "Alert engine classifies severity and maps to zones", color: T.accentAlt },
              { step: "03", label: "Automate", desc: "Matching automation rules fire actions instantly", color: T.purple },
              { step: "04", label: "Notify", desc: "Operators alerted via dashboard, email & push", color: T.green },
            ].map((s, i) => (
              <div key={i} style={{ padding: "28px 20px", position: "relative",
                borderLeft: i > 0 ? `1px solid ${T.border}` : "none" }}>
                <div style={{ fontSize: 11, color: s.color, fontFamily: "'Space Mono',monospace",
                  letterSpacing: 2, marginBottom: 8 }}>{s.step}</div>
                <div style={{ fontSize: 18, fontWeight: 800, color: T.text, marginBottom: 8 }}>{s.label}</div>
                <div style={{ fontSize: 13, color: T.muted, lineHeight: 1.6 }}>{s.desc}</div>
                {i < 3 && (
                  <div style={{ position: "absolute", right: -10, top: "50%", transform: "translateY(-50%)",
                    fontSize: 16, color: T.muted, zIndex: 1 }}>→</div>
                )}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── INTEGRATIONS ─────────────────────────────────────── */}
      <section style={{ padding: "0 24px 100px" }}>
        <div style={{ maxWidth: 900, margin: "0 auto", textAlign: "center" }}>
          <SectionTitle label="Compatible With" title="Integrations & Protocols" accent={T.purple} />
          <div style={{ display: "flex", flexWrap: "wrap", gap: 12, justifyContent: "center" }}>
            {INTEGRATIONS.map((intg, i) => (
              <div key={i} style={{ padding: "8px 18px", borderRadius: 20,
                background: T.bgCard, border: `1px solid ${T.border}`,
                fontSize: 12, color: T.muted, fontFamily: "'Space Mono',monospace" }}>
                {intg}
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* ── SYSTEM HEALTH ────────────────────────────────────── */}
      <section style={{ padding: "0 24px 100px" }}>
        <div style={{ maxWidth: 700, margin: "0 auto" }}>
          <SectionTitle label="Live Status" title="System Health" accent={T.green} />
          <div style={{ display: "flex", flexDirection: "column", gap: 10 }}>
            {[
              { label: "API Server", ok: health?.status === "healthy" },
              { label: "Database (MSSQL)", ok: health?.database === "connected" },
              { label: "WebSocket Hub", ok: health?.status === "healthy" },
              { label: "Alert Engine", ok: health?.status === "healthy" },
              { label: "Automation Service", ok: health?.status === "healthy" },
              { label: "Device Scanner", ok: health?.status === "healthy" },
            ].map((s, i) => <StatusBadge key={i} {...s} />)}
            {health && (
              <div style={{ display: "flex", gap: 16, marginTop: 12, flexWrap: "wrap" }}>
                {[
                  { label: "Uptime", value: fmtUptime(uptime) },
                  { label: "Env", value: about?.environment || "—" },
                  { label: "Version", value: about?.version || "—" },
                ].map((m, i) => (
                  <div key={i} style={{ background: T.bgCard, border: `1px solid ${T.border}`,
                    borderRadius: 8, padding: "10px 16px", flex: 1 }}>
                    <div style={{ fontSize: 10, color: T.muted, fontFamily: "'Space Mono',monospace",
                      letterSpacing: 1, textTransform: "uppercase", marginBottom: 4 }}>{m.label}</div>
                    <div style={{ fontSize: 14, fontWeight: 700, color: T.green,
                      fontFamily: "'Space Mono',monospace" }}>{m.value}</div>
                  </div>
                ))}
              </div>
            )}
          </div>
        </div>
      </section>

      {/* ── TEAM ─────────────────────────────────────────────── */}
      <section style={{ padding: "0 24px 100px" }}>
        <div style={{ maxWidth: 900, margin: "0 auto" }}>
          <SectionTitle label="Our Divisions" title="The GRT Nexus Team" accent={T.purple} />
          <div style={{ display: "grid", gridTemplateColumns: "repeat(auto-fit,minmax(180px,1fr))", gap: 20 }}>
            {TEAM.map((m, i) => <TeamCard key={i} {...m} />)}
          </div>
        </div>
      </section>

      {/* ── CONTACT STRIP ────────────────────────────────────── */}
      <section style={{ padding: "0 24px 80px" }}>
        <div style={{ maxWidth: 700, margin: "0 auto", background: T.bgCard,
          border: `1px solid ${T.border}`, borderRadius: 20, padding: "48px 40px",
          textAlign: "center", position: "relative", overflow: "hidden" }}>
          <div style={{ position: "absolute", inset: 0,
            background: `radial-gradient(ellipse at center, ${T.accent}08, transparent 70%)`,
            pointerEvents: "none" }}/>
          <div style={{ fontFamily: "'Space Mono',monospace", fontSize: 11, color: T.accent,
            letterSpacing: 4, textTransform: "uppercase", marginBottom: 12 }}>
            GET IN TOUCH
          </div>
          <h3 style={{ fontSize: 28, fontWeight: 800, color: T.text, margin: "0 0 16px" }}>
            Secure Your Facility Today
          </h3>
          <p style={{ color: T.muted, fontSize: 14, lineHeight: 1.6, margin: "0 0 32px" }}>
            GRT Assist Automations & Security Pvt. Ltd.<br/>
            Enterprise security solutions across multiple industry verticals.
          </p>
          <div style={{ display: "flex", gap: 16, justifyContent: "center", flexWrap: "wrap" }}>
            {[
              { label: "📧 security@grtassist.com", color: T.accent },
              { label: "☎ +91 98XXX XXXXX", color: T.green },
            ].map((c, i) => (
              <div key={i} style={{ padding: "10px 20px", borderRadius: 8,
                background: T.bgPanel, border: `1px solid ${T.border}`,
                fontSize: 13, color: c.color, fontFamily: "'Space Mono',monospace" }}>{c.label}</div>
            ))}
          </div>
        </div>
      </section>

      {/* ── FOOTER ───────────────────────────────────────────── */}
      <footer style={{ borderTop: `1px solid ${T.border}`, padding: "24px",
        textAlign: "center", color: T.muted, fontSize: 12,
        fontFamily: "'Space Mono',monospace", letterSpacing: 1 }}>
        © {new Date().getFullYear()} GRT ASSIST AUTOMATIONS & SECURITY PVT. LTD. — ALL RIGHTS RESERVED
      </footer>
    </div>
  );
}
