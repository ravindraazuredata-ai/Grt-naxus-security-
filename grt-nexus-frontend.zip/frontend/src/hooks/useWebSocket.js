// src/hooks/useWebSocket.js
import { useEffect, useRef, useCallback, useState } from "react";
import { token } from "../services/api";

const WS_URL = import.meta.env.VITE_WS_URL || "ws://localhost:5000/ws";

const EVENT_TYPES = {
  DEVICE_STATUS:     "device:status",
  DEVICE_DISCOVERED: "device:discovered",
  ALERT_CREATED:     "alert:created",
  ALERT_UPDATED:     "alert:updated",
  NOTIFICATION:      "notification:new",
  SCAN_PROGRESS:     "scan:progress",
  SCAN_COMPLETE:     "scan:complete",
  SYSTEM_STATUS:     "system:status",
};

export function useWebSocket(handlers = {}) {
  const ws        = useRef(null);
  const handlersR = useRef(handlers);
  const reconnectT = useRef(null);
  const [connected, setConnected] = useState(false);
  const [reconnectCount, setReconnectCount] = useState(0);

  handlersR.current = handlers;

  const connect = useCallback(() => {
    if (ws.current?.readyState === WebSocket.OPEN) return;
    const t = token.access;
    if (!t) return;

    ws.current = new WebSocket(`${WS_URL}?token=${t}`);

    ws.current.onopen = () => {
      setConnected(true);
      setReconnectCount(0);
      clearTimeout(reconnectT.current);
    };

    ws.current.onmessage = (e) => {
      try {
        const msg = JSON.parse(e.data);
        const handler = handlersR.current[msg.type];
        if (handler) handler(msg.data, msg);
        handlersR.current["*"]?.(msg);
      } catch (_) {}
    };

    ws.current.onclose = () => {
      setConnected(false);
      // Exponential back-off: 2s, 4s, 8s … max 30s
      setReconnectCount((n) => {
        const delay = Math.min(2000 * Math.pow(2, n), 30000);
        reconnectT.current = setTimeout(connect, delay);
        return n + 1;
      });
    };

    ws.current.onerror = () => ws.current?.close();
  }, []);

  useEffect(() => {
    connect();
    return () => {
      clearTimeout(reconnectT.current);
      ws.current?.close();
    };
  }, [connect]);

  const send = useCallback((type, data) => {
    if (ws.current?.readyState === WebSocket.OPEN) {
      ws.current.send(JSON.stringify({ type, data }));
    }
  }, []);

  const ping = useCallback(() => send("ping"), [send]);

  return { connected, reconnectCount, send, ping };
}

export { EVENT_TYPES };
