// src/validators/deviceValidator.js
const Joi = require('joi');

const DEVICE_TYPES = ['camera','sensor','server','workstation','network','iot','unknown'];
const STATUSES     = ['online','offline','warning','error'];

const schemas = {
  create: Joi.object({
    name:        Joi.string().max(150).required(),
    ip_address:  Joi.string().ip({ version: ['ipv4','ipv6'] }).required(),
    mac_address: Joi.string().pattern(/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/).optional().allow(null,''),
    device_type: Joi.string().valid(...DEVICE_TYPES).default('unknown'),
    location:    Joi.string().max(255).optional().allow(null,''),
    metadata:    Joi.object().optional().allow(null),
  }),

  update: Joi.object({
    name:        Joi.string().max(150),
    ip_address:  Joi.string().ip({ version: ['ipv4','ipv6'] }),
    mac_address: Joi.string().pattern(/^([0-9A-Fa-f]{2}[:-]){5}([0-9A-Fa-f]{2})$/).optional().allow(null,''),
    device_type: Joi.string().valid(...DEVICE_TYPES),
    location:    Joi.string().max(255).optional().allow(null,''),
    status:      Joi.string().valid(...STATUSES),
    metadata:    Joi.object().optional().allow(null),
  }).min(1),

  query: Joi.object({
    page:        Joi.number().integer().min(1).default(1),
    limit:       Joi.number().integer().min(1).max(200).default(50),
    status:      Joi.string().valid(...STATUSES).optional(),
    device_type: Joi.string().valid(...DEVICE_TYPES).optional(),
    search:      Joi.string().max(100).optional(),
  }),
};

function validate(schemaName) {
  return (req, res, next) => {
    const schema = schemas[schemaName];
    if (!schema) return next(new Error(`Unknown validation schema: ${schemaName}`));

    const source = schemaName === 'query' ? req.query : req.body;
    const { error, value } = schema.validate(source, { abortEarly: false, stripUnknown: true });

    if (error) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: error.details.map((d) => ({ field: d.path.join('.'), message: d.message })),
      });
    }

    if (schemaName === 'query') req.query = value;
    else req.body = value;

    next();
  };
}

module.exports = { validate, schemas };
