// src/validators/authValidator.js
const Joi = require('joi');

const passwordSchema = Joi.string()
  .min(8)
  .max(128)
  .pattern(/[A-Z]/, 'uppercase')
  .pattern(/[a-z]/, 'lowercase')
  .pattern(/[0-9]/, 'digit')
  .messages({
    'string.pattern.name': '{{#label}} must contain at least one {{#name}} character',
    'string.min': 'Password must be at least 8 characters',
  });

const schemas = {
  register: Joi.object({
    username: Joi.string().alphanum().min(3).max(100).required(),
    email:    Joi.string().email().max(255).required(),
    password: passwordSchema.required(),
    role:     Joi.string().valid('admin', 'operator', 'viewer').default('viewer'),
  }),

  login: Joi.object({
    email:    Joi.string().email().required(),
    password: Joi.string().required(),
  }),

  changePassword: Joi.object({
    current_password: Joi.string().required(),
    new_password:     passwordSchema.required(),
    confirm_password: Joi.any()
      .valid(Joi.ref('new_password'))
      .required()
      .messages({ 'any.only': 'Passwords do not match' }),
  }),

  refreshToken: Joi.object({
    refresh_token: Joi.string().required(),
  }),
};

/**
 * Returns an Express middleware that validates req.body against the named schema.
 */
function validate(schemaName) {
  return (req, res, next) => {
    const schema = schemas[schemaName];
    if (!schema) return next(new Error(`Unknown validation schema: ${schemaName}`));

    const { error, value } = schema.validate(req.body, { abortEarly: false, stripUnknown: true });
    if (error) {
      return res.status(400).json({
        success: false,
        message: 'Validation failed',
        errors: error.details.map((d) => ({ field: d.path.join('.'), message: d.message })),
      });
    }

    req.body = value; // replace with sanitised values
    next();
  };
}

module.exports = { validate, schemas };
