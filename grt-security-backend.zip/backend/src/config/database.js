// src/config/database.js
// ─────────────────────────────────────────────────────────────
//  MSSQL connection pool + schema bootstrap
// ─────────────────────────────────────────────────────────────
const sql = require('mssql');
const logger = require('../utils/logger');

const config = {
  server: process.env.DB_SERVER || 'localhost',
  port: parseInt(process.env.DB_PORT, 10) || 1433,
  database: process.env.DB_NAME || 'GRTSecurityDB',
  user: process.env.DB_USER || 'sa',
  password: process.env.DB_PASSWORD || '',
  options: {
    encrypt: process.env.DB_ENCRYPT === 'true',
    trustServerCertificate: process.env.DB_TRUST_SERVER_CERTIFICATE !== 'false',
    enableArithAbort: true,
    connectionTimeout: parseInt(process.env.DB_CONNECTION_TIMEOUT, 10) || 30000,
    requestTimeout: parseInt(process.env.DB_REQUEST_TIMEOUT, 10) || 30000,
  },
  pool: {
    max: parseInt(process.env.DB_POOL_MAX, 10) || 10,
    min: parseInt(process.env.DB_POOL_MIN, 10) || 2,
    idleTimeoutMillis: parseInt(process.env.DB_POOL_IDLE_TIMEOUT, 10) || 30000,
  },
};

let pool = null;

/**
 * Returns the active connection pool, creating it on first call.
 */
async function getPool() {
  if (pool) return pool;

  try {
    pool = await sql.connect(config);
    logger.info('✅ MSSQL connection pool established');

    pool.on('error', (err) => {
      logger.error('MSSQL pool error', { error: err.message });
      pool = null; // force reconnect on next call
    });

    return pool;
  } catch (err) {
    logger.error('❌ Failed to connect to MSSQL', { error: err.message });
    throw err;
  }
}

/**
 * Runs a parameterised query and returns the full RecordSet result.
 * @param {string} queryText   - SQL string with @param placeholders
 * @param {Object} params      - { name: { type, value } }
 */
async function query(queryText, params = {}) {
  const db = await getPool();
  const request = db.request();

  for (const [name, { type, value }] of Object.entries(params)) {
    request.input(name, type, value);
  }

  return request.query(queryText);
}

/**
 * Creates all tables if they don't already exist.
 * Safe to call on every startup.
 */
async function initializeSchema() {
  const db = await getPool();

  const schema = `
    -- Users
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Users' AND xtype='U')
    CREATE TABLE Users (
      id          UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
      username    NVARCHAR(100) NOT NULL UNIQUE,
      email       NVARCHAR(255) NOT NULL UNIQUE,
      password    NVARCHAR(255) NOT NULL,
      role        NVARCHAR(20)  NOT NULL DEFAULT 'viewer'
                  CHECK (role IN ('admin','operator','viewer')),
      is_active   BIT           NOT NULL DEFAULT 1,
      last_login  DATETIME2     NULL,
      created_at  DATETIME2     NOT NULL DEFAULT GETUTCDATE(),
      updated_at  DATETIME2     NOT NULL DEFAULT GETUTCDATE()
    );

    -- Devices
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Devices' AND xtype='U')
    CREATE TABLE Devices (
      id            UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
      name          NVARCHAR(150)  NOT NULL,
      ip_address    NVARCHAR(50)   NOT NULL UNIQUE,
      mac_address   NVARCHAR(50)   NULL,
      device_type   NVARCHAR(50)   NOT NULL DEFAULT 'unknown'
                    CHECK (device_type IN
                      ('camera','sensor','server','workstation','network','iot','unknown')),
      location      NVARCHAR(255)  NULL,
      status        NVARCHAR(20)   NOT NULL DEFAULT 'offline'
                    CHECK (status IN ('online','offline','warning','error')),
      last_seen     DATETIME2      NULL,
      metadata      NVARCHAR(MAX)  NULL,  -- JSON blob for extra attributes
      created_by    UNIQUEIDENTIFIER NULL REFERENCES Users(id),
      created_at    DATETIME2      NOT NULL DEFAULT GETUTCDATE(),
      updated_at    DATETIME2      NOT NULL DEFAULT GETUTCDATE()
    );

    -- Alerts
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Alerts' AND xtype='U')
    CREATE TABLE Alerts (
      id            UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
      device_id     UNIQUEIDENTIFIER NULL REFERENCES Devices(id) ON DELETE SET NULL,
      title         NVARCHAR(255)  NOT NULL,
      description   NVARCHAR(MAX)  NULL,
      severity      NVARCHAR(20)   NOT NULL DEFAULT 'info'
                    CHECK (severity IN ('info','low','medium','high','critical')),
      category      NVARCHAR(50)   NOT NULL DEFAULT 'general',
      status        NVARCHAR(20)   NOT NULL DEFAULT 'open'
                    CHECK (status IN ('open','acknowledged','resolved','closed')),
      acknowledged_by UNIQUEIDENTIFIER NULL REFERENCES Users(id),
      acknowledged_at DATETIME2    NULL,
      resolved_at   DATETIME2      NULL,
      metadata      NVARCHAR(MAX)  NULL,
      created_at    DATETIME2      NOT NULL DEFAULT GETUTCDATE(),
      updated_at    DATETIME2      NOT NULL DEFAULT GETUTCDATE()
    );

    -- Notifications
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='Notifications' AND xtype='U')
    CREATE TABLE Notifications (
      id          UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
      user_id     UNIQUEIDENTIFIER NULL REFERENCES Users(id) ON DELETE SET NULL,
      alert_id    UNIQUEIDENTIFIER NULL REFERENCES Alerts(id) ON DELETE SET NULL,
      type        NVARCHAR(30)   NOT NULL DEFAULT 'info'
                  CHECK (type IN ('info','warning','error','success','alert')),
      title       NVARCHAR(255)  NOT NULL,
      message     NVARCHAR(MAX)  NOT NULL,
      is_read     BIT            NOT NULL DEFAULT 0,
      channel     NVARCHAR(20)   NOT NULL DEFAULT 'in_app'
                  CHECK (channel IN ('in_app','email','sms','push')),
      sent_at     DATETIME2      NULL,
      read_at     DATETIME2      NULL,
      created_at  DATETIME2      NOT NULL DEFAULT GETUTCDATE()
    );

    -- Automation Rules
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='AutomationRules' AND xtype='U')
    CREATE TABLE AutomationRules (
      id            UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
      name          NVARCHAR(150)  NOT NULL,
      description   NVARCHAR(500)  NULL,
      trigger_type  NVARCHAR(50)   NOT NULL,
      trigger_config NVARCHAR(MAX) NOT NULL,  -- JSON
      action_type   NVARCHAR(50)   NOT NULL,
      action_config NVARCHAR(MAX)  NOT NULL,  -- JSON
      is_active     BIT            NOT NULL DEFAULT 1,
      last_triggered DATETIME2     NULL,
      trigger_count INT            NOT NULL DEFAULT 0,
      created_by    UNIQUEIDENTIFIER NULL REFERENCES Users(id),
      created_at    DATETIME2      NOT NULL DEFAULT GETUTCDATE(),
      updated_at    DATETIME2      NOT NULL DEFAULT GETUTCDATE()
    );

    -- Automation Execution Log
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='AutomationLogs' AND xtype='U')
    CREATE TABLE AutomationLogs (
      id          UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
      rule_id     UNIQUEIDENTIFIER NOT NULL REFERENCES AutomationRules(id) ON DELETE CASCADE,
      status      NVARCHAR(20)   NOT NULL CHECK (status IN ('success','failure','skipped')),
      result      NVARCHAR(MAX)  NULL,
      error       NVARCHAR(MAX)  NULL,
      executed_at DATETIME2      NOT NULL DEFAULT GETUTCDATE()
    );

    -- Refresh Tokens
    IF NOT EXISTS (SELECT * FROM sysobjects WHERE name='RefreshTokens' AND xtype='U')
    CREATE TABLE RefreshTokens (
      id          UNIQUEIDENTIFIER PRIMARY KEY DEFAULT NEWID(),
      user_id     UNIQUEIDENTIFIER NOT NULL REFERENCES Users(id) ON DELETE CASCADE,
      token       NVARCHAR(512)  NOT NULL UNIQUE,
      expires_at  DATETIME2      NOT NULL,
      created_at  DATETIME2      NOT NULL DEFAULT GETUTCDATE()
    );
  `;

  await db.request().query(schema);
  logger.info('✅ Database schema initialised');
}

async function closePool() {
  if (pool) {
    await pool.close();
    pool = null;
    logger.info('MSSQL pool closed');
  }
}

module.exports = { sql, getPool, query, initializeSchema, closePool };
