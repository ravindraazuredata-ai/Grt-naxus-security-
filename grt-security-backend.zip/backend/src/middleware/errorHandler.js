// src/middleware/errorHandler.js
const logger = require('../utils/logger');

/**
 * 404 handler – mount BEFORE errorHandler, AFTER all routes.
 */
function notFound(req, res, next) {
  res.status(404).json({
    success: false,
    message: `Route not found: ${req.method} ${req.originalUrl}`,
  });
}

/**
 * Global error handler – mount LAST.
 */
// eslint-disable-next-line no-unused-vars
function errorHandler(err, req, res, next) {
  // Validation errors from express-validator / Joi
  if (err.isJoi || err.type === 'entity.parse.failed') {
    return res.status(400).json({ success: false, message: err.message });
  }

  // MSSQL unique constraint violations
  if (err.number === 2627 || err.number === 2601) {
    return res.status(409).json({
      success: false,
      message: 'A record with that value already exists',
    });
  }

  // MSSQL foreign-key violations
  if (err.number === 547) {
    return res.status(400).json({
      success: false,
      message: 'Referenced record does not exist',
    });
  }

  const statusCode = err.statusCode || err.status || 500;
  const message    = err.expose ? err.message
    : statusCode < 500       ? err.message
    : 'Internal server error';

  logger.error('Unhandled error', {
    method:  req.method,
    url:     req.originalUrl,
    status:  statusCode,
    error:   err.message,
    stack:   process.env.NODE_ENV === 'development' ? err.stack : undefined,
    user:    req.user?.id,
  });

  res.status(statusCode).json({
    success: false,
    message,
    ...(process.env.NODE_ENV === 'development' && { stack: err.stack }),
  });
}

/**
 * Wrap an async route handler so errors propagate to errorHandler.
 */
function asyncHandler(fn) {
  return (req, res, next) => Promise.resolve(fn(req, res, next)).catch(next);
}

module.exports = { notFound, errorHandler, asyncHandler };
