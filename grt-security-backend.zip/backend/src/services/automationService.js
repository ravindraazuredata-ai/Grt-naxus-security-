// src/services/automationService.js
// ─────────────────────────────────────────────────────────────
//  Automation rule engine.
//  Loads active rules, evaluates events against trigger configs,
//  and executes configured actions.
// ─────────────────────────────────────────────────────────────
const cron           = require('node-cron');
const AutomationRule = require('../models/AutomationRule');
const Notification   = require('../models/Notification');
const logger         = require('../utils/logger');

/** In-memory cache of active rules */
let activeRules = [];
const scheduledJobs = new Map(); // ruleId -> cron job

// ── Bootstrap ─────────────────────────────────────────────────

async function init() {
  await reloadRules();
  logger.info('✅ Automation service initialised');
}

async function reloadRules() {
  // Destroy existing schedule jobs
  scheduledJobs.forEach((job) => job.destroy());
  scheduledJobs.clear();

  try {
    activeRules = await AutomationRule.getActiveRules();
    logger.info(`Automation: loaded ${activeRules.length} active rules`);

    // Register cron-based triggers
    activeRules
      .filter((r) => r.trigger_type === 'schedule')
      .forEach((rule) => {
        const { cron_expr } = rule.trigger_config;
        if (!cron_expr || !cron.validate(cron_expr)) {
          logger.warn(`Invalid cron for rule "${rule.name}": ${cron_expr}`);
          return;
        }
        const job = cron.schedule(cron_expr, () => executeAction(rule, { triggered_by: 'schedule' }));
        scheduledJobs.set(rule.id, job);
        logger.debug(`Scheduled rule "${rule.name}" — ${cron_expr}`);
      });
  } catch (err) {
    logger.error('Failed to reload automation rules', { error: err.message });
  }
}

// ── Event evaluation ──────────────────────────────────────────

/**
 * Call this whenever a relevant event occurs in the system.
 * @param {'alert_created'|'device_status_change'|'alert_count'} eventType
 * @param {Object} eventData
 */
async function evaluateEvent(eventType, eventData) {
  const candidates = activeRules.filter((r) => {
    switch (r.trigger_type) {
      case 'alert_severity':
        return eventType === 'alert_created' &&
          r.trigger_config.severity === eventData.severity;

      case 'device_offline':
        return eventType === 'device_status_change' &&
          eventData.new_status === 'offline' &&
          (!r.trigger_config.device_id || r.trigger_config.device_id === eventData.device_id);

      case 'device_status_change':
        return eventType === 'device_status_change' &&
          r.trigger_config.new_status === eventData.new_status;

      case 'alert_count':
        return eventType === 'alert_count' &&
          eventData.count >= r.trigger_config.threshold;

      default:
        return false;
    }
  });

  await Promise.all(candidates.map((rule) => executeAction(rule, eventData)));
}

// ── Action execution ──────────────────────────────────────────

async function executeAction(rule, eventData) {
  let status = 'success';
  let result = null;
  let error  = null;

  try {
    result = await dispatchAction(rule.action_type, rule.action_config, eventData);
    logger.info(`Automation executed: "${rule.name}"`, { action: rule.action_type });
  } catch (err) {
    status = 'failure';
    error  = err.message;
    logger.warn(`Automation failed: "${rule.name}"`, { error: err.message });
  }

  try {
    await AutomationRule.recordExecution(rule.id, status, result, error);
  } catch (logErr) {
    logger.error('Failed to log automation execution', { error: logErr.message });
  }
}

async function dispatchAction(actionType, actionConfig, eventData) {
  switch (actionType) {
    case 'send_notification': {
      const { title, message, user_id } = actionConfig;
      await Notification.broadcastCreate(
        eventData.alert_id || null,
        'warning',
        title || 'Automation Alert',
        interpolate(message || 'Automated notification triggered.', eventData)
      );
      return { notified: true };
    }

    case 'send_email': {
      const notifService = require('./notificationService');
      await notifService.sendEmail({
        to:      actionConfig.to,
        subject: interpolate(actionConfig.subject || 'GRT Security Alert', eventData),
        html:    `<p>${interpolate(actionConfig.body || JSON.stringify(eventData), eventData)}</p>`,
        text:    interpolate(actionConfig.body || '', eventData),
      });
      return { email_sent_to: actionConfig.to };
    }

    case 'create_alert': {
      const alertEngine = require('./alertEngine');
      const alert = await alertEngine.raise({
        title:       interpolate(actionConfig.title || 'Automated Alert', eventData),
        description: interpolate(actionConfig.description || '', eventData),
        severity:    actionConfig.severity || 'medium',
        category:    actionConfig.category || 'automation',
        device_id:   eventData.device_id || null,
      });
      return { alert_id: alert.id };
    }

    case 'webhook': {
      const { url, method = 'POST', headers = {} } = actionConfig;
      if (!url) throw new Error('Webhook URL not configured');
      // In production use node-fetch / axios
      // fetch(url, { method, headers: { 'Content-Type': 'application/json', ...headers }, body: JSON.stringify(eventData) });
      logger.info('Webhook action (stub)', { url, method });
      return { webhook_url: url };
    }

    case 'disable_device': {
      const Device = require('../models/Device');
      const deviceId = actionConfig.device_id || eventData.device_id;
      if (!deviceId) throw new Error('No device_id for disable_device action');
      await Device.updateStatus(deviceId, 'offline');
      return { disabled_device: deviceId };
    }

    default:
      throw new Error(`Unknown action type: ${actionType}`);
  }
}

/**
 * Run a rule once with mock event data (for /test endpoint).
 */
async function testRule(rule, mockEvent = {}) {
  await executeAction(rule, mockEvent);
  return { rule_id: rule.id, executed: true };
}

/**
 * Simple {{key}} interpolation from eventData.
 */
function interpolate(template, data) {
  return template.replace(/\{\{(\w+)\}\}/g, (_, key) => data[key] ?? `{{${key}}}`);
}

module.exports = { init, reloadRules, evaluateEvent, testRule };
