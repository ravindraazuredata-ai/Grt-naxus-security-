// src/services/deviceScanning.js
// ─────────────────────────────────────────────────────────────
//  Periodic device health checks + subnet discovery.
//  Emits WS events so the dashboard updates in real time.
// ─────────────────────────────────────────────────────────────
const ping  = require('ping');
const cron  = require('node-cron');
const Device = require('../models/Device');
const Alert  = require('../models/Alert');
const ws     = require('./websocket');
const logger = require('../utils/logger');

const PING_TIMEOUT = parseInt(process.env.PING_TIMEOUT_MS, 10) || 3000;

// Track previous statuses to detect changes
const previousStatuses = new Map(); // deviceId -> status

/**
 * Ping a single host. Returns true if alive.
 */
async function pingHost(ip) {
  try {
    const res = await ping.promise.probe(ip, {
      timeout: PING_TIMEOUT / 1000,
      extra: ['-c', '1'],
    });
    return res.alive;
  } catch {
    return false;
  }
}

/**
 * Check all registered devices and update their status.
 */
async function checkAllDevices() {
  logger.debug('Device health check started');

  let allDevices = [];
  try {
    const result = await Device.findAll({ limit: 1000 });
    allDevices = result.devices;
  } catch (err) {
    logger.error('Failed to fetch devices for scanning', { error: err.message });
    return;
  }

  await Promise.all(
    allDevices.map(async (device) => {
      try {
        const alive   = await pingHost(device.ip_address);
        const newStatus = alive ? 'online' : 'offline';
        const prevStatus = previousStatuses.get(device.id);

        // Always update last_seen if online
        await Device.updateStatus(device.id, newStatus);

        // Broadcast status update via WS
        ws.broadcast(ws.EVENT_TYPES.DEVICE_STATUS, {
          device_id:  device.id,
          device_name: device.name,
          ip_address: device.ip_address,
          status:     newStatus,
        });

        // Raise an alert only on negative transition
        if (prevStatus === 'online' && newStatus === 'offline') {
          await Alert.create({
            device_id:   device.id,
            title:       `Device Offline: ${device.name}`,
            description: `${device.name} (${device.ip_address}) stopped responding to pings.`,
            severity:    device.device_type === 'camera' ? 'high' : 'medium',
            category:    'device_health',
          });

          ws.broadcastToStaff(ws.EVENT_TYPES.ALERT_CREATED, {
            severity: 'medium',
            message:  `${device.name} went offline`,
          });
        }

        previousStatuses.set(device.id, newStatus);
      } catch (err) {
        logger.warn('Error checking device', { device: device.ip_address, error: err.message });
      }
    })
  );

  logger.debug('Device health check complete', { checked: allDevices.length });
}

/**
 * Scan a subnet for live hosts (e.g. "192.168.1").
 * Discovered IPs that aren't yet in the DB are reported via WS.
 */
async function scanSubnet(subnet = '192.168.1') {
  const total = 254;
  let found = 0;

  logger.info('Subnet scan started', { subnet });
  ws.broadcastToStaff(ws.EVENT_TYPES.SCAN_PROGRESS, { subnet, total, found, pct: 0 });

  const existingResult = await Device.findAll({ limit: 1000 });
  const knownIps = new Set(existingResult.devices.map((d) => d.ip_address));

  for (let i = 1; i <= total; i++) {
    const ip = `${subnet}.${i}`;
    const alive = await pingHost(ip);

    if (alive) {
      found++;
      const isNew = !knownIps.has(ip);

      ws.broadcastToStaff(ws.EVENT_TYPES.DEVICE_STATUS, {
        ip_address: ip,
        status: 'online',
        is_new: isNew,
      });

      if (isNew) {
        ws.broadcastToStaff(ws.EVENT_TYPES.DEVICE_DISCOVERED, { ip_address: ip });
      }
    }

    // Progress update every 25 IPs
    if (i % 25 === 0) {
      ws.broadcastToStaff(ws.EVENT_TYPES.SCAN_PROGRESS, {
        subnet, total, found, pct: Math.round((i / total) * 100),
      });
    }
  }

  ws.broadcastToStaff(ws.EVENT_TYPES.SCAN_COMPLETE, { subnet, total_alive: found });
  logger.info('Subnet scan complete', { subnet, found });
}

/**
 * Start the periodic health-check cron job.
 */
function startScheduler() {
  const intervalMinutes = parseInt(process.env.SCAN_INTERVAL_MINUTES, 10) || 5;
  const cronExpr = `*/${intervalMinutes} * * * *`;

  cron.schedule(cronExpr, async () => {
    try {
      await checkAllDevices();
    } catch (err) {
      logger.error('Scheduled device check failed', { error: err.message });
    }
  });

  logger.info(`✅ Device scanner scheduled every ${intervalMinutes} minutes`);
}

module.exports = { pingHost, checkAllDevices, scanSubnet, startScheduler };
