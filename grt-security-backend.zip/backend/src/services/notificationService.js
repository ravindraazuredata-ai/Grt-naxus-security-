// src/services/notificationService.js
// ─────────────────────────────────────────────────────────────
//  Outbound notification delivery — email via Nodemailer.
//  Extend here for SMS, Slack, webhook, push etc.
// ─────────────────────────────────────────────────────────────
const nodemailer = require('nodemailer');
const Notification = require('../models/Notification');
const ws = require('./websocket');
const logger = require('../utils/logger');

let transporter = null;

function getTransporter() {
  if (transporter) return transporter;

  transporter = nodemailer.createTransport({
    host:   process.env.SMTP_HOST || 'smtp.gmail.com',
    port:   parseInt(process.env.SMTP_PORT, 10) || 587,
    secure: process.env.SMTP_SECURE === 'true',
    auth: {
      user: process.env.SMTP_USER,
      pass: process.env.SMTP_PASS,
    },
  });

  return transporter;
}

/**
 * Send a single email.
 */
async function sendEmail({ to, subject, html, text }) {
  if (!process.env.SMTP_USER || !process.env.SMTP_PASS) {
    logger.warn('Email not configured — skipping send');
    return;
  }

  try {
    const info = await getTransporter().sendMail({
      from:    process.env.EMAIL_FROM || `"GRT Security" <${process.env.SMTP_USER}>`,
      to,
      subject,
      html,
      text,
    });
    logger.info('Email sent', { to, messageId: info.messageId });
    return info;
  } catch (err) {
    logger.error('Email delivery failed', { to, error: err.message });
    throw err;
  }
}

/**
 * Email admin on critical/high alerts.
 */
async function sendCriticalAlertEmail(alert) {
  const to = process.env.CRITICAL_ALERT_EMAIL;
  if (!to) return;

  const subject = `[${alert.severity.toUpperCase()}] GRT Security Alert: ${alert.title}`;
  const html = `
    <div style="font-family: Arial, sans-serif; max-width:600px; margin:auto;">
      <div style="background:#1a1a2e; padding:20px; border-radius:8px 8px 0 0;">
        <h1 style="color:#ff6b35; margin:0; font-size:20px;">⚠ GRT Security Platform</h1>
      </div>
      <div style="background:#fff; padding:24px; border:1px solid #ddd; border-top:none; border-radius:0 0 8px 8px;">
        <h2 style="color:#333;">${alert.title}</h2>
        <table style="width:100%; border-collapse:collapse;">
          <tr><td style="padding:8px; color:#666; font-weight:bold; width:120px;">Severity</td>
              <td style="padding:8px; color:#e74c3c; font-weight:bold;">${alert.severity.toUpperCase()}</td></tr>
          <tr><td style="padding:8px; color:#666; font-weight:bold;">Category</td>
              <td style="padding:8px;">${alert.category}</td></tr>
          <tr><td style="padding:8px; color:#666; font-weight:bold;">Time</td>
              <td style="padding:8px;">${new Date(alert.created_at).toUTCString()}</td></tr>
          ${alert.description ? `<tr><td style="padding:8px; color:#666; font-weight:bold; vertical-align:top;">Details</td>
              <td style="padding:8px;">${alert.description}</td></tr>` : ''}
        </table>
        <p style="margin-top:20px;">
          <a href="${process.env.CLIENT_ORIGIN}/alerts/${alert.id}"
             style="background:#ff6b35; color:#fff; padding:10px 20px; border-radius:4px; text-decoration:none;">
            View Alert →
          </a>
        </p>
      </div>
    </div>`;

  await sendEmail({ to, subject, html, text: `${alert.severity.toUpperCase()}: ${alert.title}\n${alert.description || ''}` });
}

/**
 * Process queued email notifications (call from cron or startup).
 */
async function flushEmailQueue() {
  const pending = await Notification.getPendingEmail();
  if (!pending.length) return;

  logger.info(`Flushing ${pending.length} pending email notifications`);

  await Promise.all(
    pending.map(async (n) => {
      try {
        await sendEmail({
          to:      n.user_email,
          subject: n.title,
          html:    `<p>${n.message}</p>`,
          text:    n.message,
        });
        await Notification.markSent(n.id);
      } catch (err) {
        logger.warn('Failed to send queued notification', { id: n.id, error: err.message });
      }
    })
  );
}

/**
 * Push an in-app notification and forward to WS.
 */
async function sendInApp(userId, { type, title, message, alert_id }) {
  const notification = await Notification.create({
    user_id:  userId,
    alert_id: alert_id || null,
    type,
    title,
    message,
    channel:  'in_app',
  });

  ws.sendToUser(userId, ws.EVENT_TYPES.NOTIFICATION, notification);
  return notification;
}

module.exports = { sendEmail, sendCriticalAlertEmail, flushEmailQueue, sendInApp };
