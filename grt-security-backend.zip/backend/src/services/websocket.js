// src/services/websocket.js
// ─────────────────────────────────────────────────────────────
//  WebSocket server — real-time event hub for the dashboard.
//  Clients authenticate with a JWT query param on connect.
// ─────────────────────────────────────────────────────────────
const { WebSocketServer } = require('ws');
const jwt  = require('jsonwebtoken');
const User = require('../models/User');
const logger = require('../utils/logger');

/** @type {WebSocketServer | null} */
let wss = null;

// Map<userId, Set<WebSocket>>
const userSockets = new Map();

const EVENT_TYPES = {
  DEVICE_STATUS:    'device:status',
  DEVICE_DISCOVERED:'device:discovered',
  ALERT_CREATED:    'alert:created',
  ALERT_UPDATED:    'alert:updated',
  NOTIFICATION:     'notification:new',
  SCAN_PROGRESS:    'scan:progress',
  SCAN_COMPLETE:    'scan:complete',
  SYSTEM_STATUS:    'system:status',
  PING:             'ping',
  PONG:             'pong',
};

/**
 * Initialise the WS server, attaching to an existing HTTP server.
 * @param {import('http').Server} httpServer
 */
function init(httpServer) {
  wss = new WebSocketServer({ server: httpServer, path: '/ws' });

  wss.on('connection', async (ws, req) => {
    const url = new URL(req.url, `http://${req.headers.host}`);
    const token = url.searchParams.get('token');

    // Authenticate
    let user = null;
    try {
      const decoded = jwt.verify(token, process.env.JWT_SECRET);
      user = await User.findById(decoded.id);
    } catch { /* invalid token — will disconnect */ }

    if (!user) {
      ws.close(4001, 'Unauthorized');
      return;
    }

    ws.userId = user.id;
    ws.userRole = user.role;
    ws.isAlive = true;

    // Register socket
    if (!userSockets.has(user.id)) userSockets.set(user.id, new Set());
    userSockets.get(user.id).add(ws);

    logger.info('WS client connected', { userId: user.id, ip: req.socket.remoteAddress });

    // Send welcome
    send(ws, { type: EVENT_TYPES.SYSTEM_STATUS, data: { message: 'Connected', userId: user.id } });

    // Handle incoming messages
    ws.on('message', (raw) => {
      try {
        const msg = JSON.parse(raw.toString());
        if (msg.type === EVENT_TYPES.PING) send(ws, { type: EVENT_TYPES.PONG });
      } catch { /* ignore malformed */ }
    });

    ws.on('pong', () => { ws.isAlive = true; });

    ws.on('close', () => {
      userSockets.get(user.id)?.delete(ws);
      if (!userSockets.get(user.id)?.size) userSockets.delete(user.id);
      logger.info('WS client disconnected', { userId: user.id });
    });

    ws.on('error', (err) => {
      logger.warn('WS error', { userId: user.id, error: err.message });
    });
  });

  // Heartbeat — terminate dead connections every 30 s
  const heartbeat = setInterval(() => {
    wss.clients.forEach((ws) => {
      if (!ws.isAlive) return ws.terminate();
      ws.isAlive = false;
      ws.ping();
    });
  }, 30_000);

  wss.on('close', () => clearInterval(heartbeat));

  logger.info('✅ WebSocket server initialised');
  return wss;
}

// ── Sending helpers ───────────────────────────────────────────

function send(ws, payload) {
  if (ws.readyState === ws.OPEN) {
    ws.send(JSON.stringify({ ...payload, ts: Date.now() }));
  }
}

/** Broadcast to all connected authenticated clients */
function broadcast(type, data) {
  if (!wss) return;
  const msg = JSON.stringify({ type, data, ts: Date.now() });
  wss.clients.forEach((ws) => {
    if (ws.readyState === ws.OPEN) ws.send(msg);
  });
}

/** Send to all sockets owned by a specific user */
function sendToUser(userId, type, data) {
  const sockets = userSockets.get(userId);
  if (!sockets) return;
  const msg = JSON.stringify({ type, data, ts: Date.now() });
  sockets.forEach((ws) => {
    if (ws.readyState === ws.OPEN) ws.send(msg);
  });
}

/** Send to all admins and operators */
function broadcastToStaff(type, data) {
  if (!wss) return;
  const msg = JSON.stringify({ type, data, ts: Date.now() });
  wss.clients.forEach((ws) => {
    if (ws.readyState === ws.OPEN && ['admin','operator'].includes(ws.userRole)) {
      ws.send(msg);
    }
  });
}

function connectedCount() {
  return wss ? wss.clients.size : 0;
}

module.exports = {
  init,
  broadcast,
  broadcastToStaff,
  sendToUser,
  connectedCount,
  EVENT_TYPES,
};
