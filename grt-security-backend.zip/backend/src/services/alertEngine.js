// src/services/alertEngine.js
// ─────────────────────────────────────────────────────────────
//  Alert engine — creates, enriches, and fans out alerts.
//  Call alertEngine.raise() from anywhere in the app.
// ─────────────────────────────────────────────────────────────
const Alert        = require('../models/Alert');
const Notification = require('../models/Notification');
const ws           = require('./websocket');
const notifService = require('./notificationService');
const automationService = require('./automationService');
const logger       = require('../utils/logger');

/**
 * Central method: create an alert, fan out notifications, trigger automations.
 *
 * @param {Object} opts
 * @param {string}  [opts.device_id]
 * @param {string}   opts.title
 * @param {string}  [opts.description]
 * @param {'info'|'low'|'medium'|'high'|'critical'} [opts.severity='info']
 * @param {string}  [opts.category='general']
 * @param {Object}  [opts.metadata]
 */
async function raise(opts) {
  const {
    device_id,
    title,
    description,
    severity  = 'info',
    category  = 'general',
    metadata,
  } = opts;

  let alert;
  try {
    alert = await Alert.create({ device_id, title, description, severity, category, metadata });
  } catch (err) {
    logger.error('AlertEngine: failed to create alert', { error: err.message });
    throw err;
  }

  // ── Real-time WebSocket broadcast ────────────────────────────
  ws.broadcastToStaff(ws.EVENT_TYPES.ALERT_CREATED, {
    alert_id:  alert.id,
    title:     alert.title,
    severity:  alert.severity,
    category:  alert.category,
    device_id: alert.device_id,
    created_at: alert.created_at,
  });

  // ── In-app notifications for admin/operator ──────────────────
  try {
    await Notification.broadcastCreate(
      alert.id,
      severityToNotifType(severity),
      title,
      description || `Severity: ${severity} | Category: ${category}`
    );
  } catch (err) {
    logger.warn('AlertEngine: notification fan-out failed', { error: err.message });
  }

  // ── Email for critical/high alerts ───────────────────────────
  if (['critical', 'high'].includes(severity)) {
    notifService.sendCriticalAlertEmail(alert).catch((err) => {
      logger.warn('AlertEngine: critical email failed', { error: err.message });
    });
  }

  // ── Trigger automation rules ─────────────────────────────────
  automationService.evaluateEvent('alert_created', {
    alert_id: alert.id,
    severity,
    category,
    device_id,
  }).catch((err) => {
    logger.warn('AlertEngine: automation eval failed', { error: err.message });
  });

  logger.info('Alert raised', { id: alert.id, severity, title });
  return alert;
}

/**
 * Escalate an existing alert's severity.
 */
async function escalate(alertId, newSeverity) {
  const alert = await Alert.findById(alertId);
  if (!alert) throw new Error(`Alert ${alertId} not found`);

  // Update via raw query since Alert model doesn't have generic update
  const { sql, query } = require('../config/database');
  await query(
    `UPDATE Alerts SET severity = @sev, updated_at = GETUTCDATE() WHERE id = @id`,
    {
      id:  { type: sql.UniqueIdentifier, value: alertId },
      sev: { type: sql.NVarChar(20),     value: newSeverity },
    }
  );

  ws.broadcastToStaff(ws.EVENT_TYPES.ALERT_UPDATED, {
    alert_id: alertId,
    severity: newSeverity,
    action:   'escalated',
  });

  logger.info('Alert escalated', { id: alertId, severity: newSeverity });
}

function severityToNotifType(severity) {
  const map = { info: 'info', low: 'info', medium: 'warning', high: 'error', critical: 'error' };
  return map[severity] || 'info';
}

module.exports = { raise, escalate };
