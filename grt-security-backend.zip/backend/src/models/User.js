// src/models/User.js
const { sql, query } = require('../config/database');
const bcrypt = require('bcryptjs');

const SALT_ROUNDS = 12;

class User {
  // ── Create ─────────────────────────────────────────────────
  static async create({ username, email, password, role = 'viewer' }) {
    const hash = await bcrypt.hash(password, SALT_ROUNDS);

    const result = await query(
      `INSERT INTO Users (username, email, password, role)
       OUTPUT INSERTED.*
       VALUES (@username, @email, @password, @role)`,
      {
        username: { type: sql.NVarChar(100), value: username },
        email:    { type: sql.NVarChar(255), value: email },
        password: { type: sql.NVarChar(255), value: hash },
        role:     { type: sql.NVarChar(20),  value: role },
      }
    );

    return User._sanitize(result.recordset[0]);
  }

  // ── Find by ID ─────────────────────────────────────────────
  static async findById(id) {
    const result = await query(
      `SELECT * FROM Users WHERE id = @id AND is_active = 1`,
      { id: { type: sql.UniqueIdentifier, value: id } }
    );
    return result.recordset[0] ? User._sanitize(result.recordset[0]) : null;
  }

  // ── Find by email (includes password for auth) ─────────────
  static async findByEmailRaw(email) {
    const result = await query(
      `SELECT * FROM Users WHERE email = @email`,
      { email: { type: sql.NVarChar(255), value: email } }
    );
    return result.recordset[0] || null;
  }

  // ── Find by username ───────────────────────────────────────
  static async findByUsername(username) {
    const result = await query(
      `SELECT * FROM Users WHERE username = @username AND is_active = 1`,
      { username: { type: sql.NVarChar(100), value: username } }
    );
    return result.recordset[0] ? User._sanitize(result.recordset[0]) : null;
  }

  // ── List all (paginated) ───────────────────────────────────
  static async findAll({ page = 1, limit = 20, role } = {}) {
    const offset = (page - 1) * limit;
    let whereClause = 'WHERE is_active = 1';
    const params = {
      limit:  { type: sql.Int, value: limit },
      offset: { type: sql.Int, value: offset },
    };

    if (role) {
      whereClause += ' AND role = @role';
      params.role = { type: sql.NVarChar(20), value: role };
    }

    const countRes = await query(
      `SELECT COUNT(*) AS total FROM Users ${whereClause}`,
      role ? { role: params.role } : {}
    );
    const total = countRes.recordset[0].total;

    const result = await query(
      `SELECT * FROM Users ${whereClause}
       ORDER BY created_at DESC
       OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY`,
      params
    );

    return { users: result.recordset.map(User._sanitize), total, page, limit };
  }

  // ── Update ─────────────────────────────────────────────────
  static async update(id, fields) {
    const allowed = ['username', 'email', 'role', 'is_active'];
    const setClauses = [];
    const params = { id: { type: sql.UniqueIdentifier, value: id } };

    for (const [key, val] of Object.entries(fields)) {
      if (!allowed.includes(key)) continue;
      setClauses.push(`${key} = @${key}`);
      params[key] = {
        type: key === 'is_active' ? sql.Bit : sql.NVarChar(255),
        value: val,
      };
    }

    if (!setClauses.length) throw new Error('No valid fields to update');

    setClauses.push(`updated_at = GETUTCDATE()`);

    const result = await query(
      `UPDATE Users SET ${setClauses.join(', ')}
       OUTPUT INSERTED.*
       WHERE id = @id`,
      params
    );

    return result.recordset[0] ? User._sanitize(result.recordset[0]) : null;
  }

  // ── Change password ────────────────────────────────────────
  static async changePassword(id, newPassword) {
    const hash = await bcrypt.hash(newPassword, SALT_ROUNDS);
    await query(
      `UPDATE Users SET password = @password, updated_at = GETUTCDATE()
       WHERE id = @id`,
      {
        id:       { type: sql.UniqueIdentifier, value: id },
        password: { type: sql.NVarChar(255), value: hash },
      }
    );
  }

  // ── Soft delete ────────────────────────────────────────────
  static async deactivate(id) {
    await query(
      `UPDATE Users SET is_active = 0, updated_at = GETUTCDATE()
       WHERE id = @id`,
      { id: { type: sql.UniqueIdentifier, value: id } }
    );
  }

  // ── Update last login ──────────────────────────────────────
  static async touchLastLogin(id) {
    await query(
      `UPDATE Users SET last_login = GETUTCDATE() WHERE id = @id`,
      { id: { type: sql.UniqueIdentifier, value: id } }
    );
  }

  // ── Password verification ──────────────────────────────────
  static async verifyPassword(plainText, hash) {
    return bcrypt.compare(plainText, hash);
  }

  // ── Strip sensitive fields ─────────────────────────────────
  static _sanitize(row) {
    const { password, ...safe } = row;
    return safe;
  }
}

module.exports = User;
