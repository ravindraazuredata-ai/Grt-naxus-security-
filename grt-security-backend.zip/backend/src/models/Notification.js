// src/models/Notification.js
const { sql, query } = require('../config/database');

class Notification {
  static async create({ user_id, alert_id, type = 'info', title, message, channel = 'in_app' }) {
    const result = await query(
      `INSERT INTO Notifications (user_id, alert_id, type, title, message, channel)
       OUTPUT INSERTED.*
       VALUES (@user_id, @alert_id, @type, @title, @message, @channel)`,
      {
        user_id:  { type: sql.UniqueIdentifier, value: user_id  || null },
        alert_id: { type: sql.UniqueIdentifier, value: alert_id || null },
        type:     { type: sql.NVarChar(30),     value: type    },
        title:    { type: sql.NVarChar(255),    value: title   },
        message:  { type: sql.NVarChar(sql.MAX),value: message },
        channel:  { type: sql.NVarChar(20),     value: channel },
      }
    );
    return result.recordset[0];
  }

  static async findForUser(userId, { page = 1, limit = 30, unread_only = false } = {}) {
    const offset = (page - 1) * limit;
    let where = 'WHERE n.user_id = @user_id';
    const params = {
      user_id: { type: sql.UniqueIdentifier, value: userId },
      limit:   { type: sql.Int, value: limit },
      offset:  { type: sql.Int, value: offset },
    };

    if (unread_only) where += ' AND n.is_read = 0';

    const countRes = await query(
      `SELECT COUNT(*) AS total FROM Notifications n ${where}`,
      { user_id: params.user_id }
    );

    const result = await query(
      `SELECT n.*, a.title AS alert_title, a.severity AS alert_severity
       FROM Notifications n
       LEFT JOIN Alerts a ON n.alert_id = a.id
       ${where}
       ORDER BY n.created_at DESC
       OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY`,
      params
    );

    return {
      notifications: result.recordset,
      total: countRes.recordset[0].total,
      unread_count: await Notification.unreadCount(userId),
      page,
      limit,
    };
  }

  static async markRead(id, userId) {
    await query(
      `UPDATE Notifications
       SET is_read = 1, read_at = GETUTCDATE()
       WHERE id = @id AND user_id = @user_id`,
      {
        id:      { type: sql.UniqueIdentifier, value: id },
        user_id: { type: sql.UniqueIdentifier, value: userId },
      }
    );
  }

  static async markAllRead(userId) {
    await query(
      `UPDATE Notifications SET is_read = 1, read_at = GETUTCDATE()
       WHERE user_id = @user_id AND is_read = 0`,
      { user_id: { type: sql.UniqueIdentifier, value: userId } }
    );
  }

  static async unreadCount(userId) {
    const result = await query(
      `SELECT COUNT(*) AS count FROM Notifications WHERE user_id = @user_id AND is_read = 0`,
      { user_id: { type: sql.UniqueIdentifier, value: userId } }
    );
    return result.recordset[0].count;
  }

  static async broadcastCreate(alert_id, type, title, message) {
    // Fan-out to all active admin/operator users
    await query(
      `INSERT INTO Notifications (user_id, alert_id, type, title, message, channel)
       SELECT id, @alert_id, @type, @title, @message, 'in_app'
       FROM Users
       WHERE is_active = 1 AND role IN ('admin','operator')`,
      {
        alert_id: { type: sql.UniqueIdentifier,   value: alert_id || null },
        type:     { type: sql.NVarChar(30),        value: type    },
        title:    { type: sql.NVarChar(255),       value: title   },
        message:  { type: sql.NVarChar(sql.MAX),   value: message },
      }
    );
  }

  static async markSent(id) {
    await query(
      `UPDATE Notifications SET sent_at = GETUTCDATE() WHERE id = @id`,
      { id: { type: sql.UniqueIdentifier, value: id } }
    );
  }

  static async getPendingEmail() {
    const result = await query(
      `SELECT n.*, u.email AS user_email, u.username
       FROM Notifications n
       JOIN Users u ON n.user_id = u.id
       WHERE n.channel = 'email' AND n.sent_at IS NULL
       ORDER BY n.created_at ASC`
    );
    return result.recordset;
  }
}

module.exports = Notification;
