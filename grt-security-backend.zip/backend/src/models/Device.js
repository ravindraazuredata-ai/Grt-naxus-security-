// src/models/Device.js
const { sql, query } = require('../config/database');

class Device {
  static async create({ name, ip_address, mac_address, device_type = 'unknown', location, metadata, created_by }) {
    const result = await query(
      `INSERT INTO Devices (name, ip_address, mac_address, device_type, location, metadata, created_by)
       OUTPUT INSERTED.*
       VALUES (@name, @ip, @mac, @type, @location, @metadata, @created_by)`,
      {
        name:       { type: sql.NVarChar(150), value: name },
        ip:         { type: sql.NVarChar(50),  value: ip_address },
        mac:        { type: sql.NVarChar(50),  value: mac_address || null },
        type:       { type: sql.NVarChar(50),  value: device_type },
        location:   { type: sql.NVarChar(255), value: location || null },
        metadata:   { type: sql.NVarChar(sql.MAX), value: metadata ? JSON.stringify(metadata) : null },
        created_by: { type: sql.UniqueIdentifier, value: created_by || null },
      }
    );
    return Device._parse(result.recordset[0]);
  }

  static async findById(id) {
    const result = await query(
      `SELECT d.*, u.username AS created_by_name
       FROM Devices d
       LEFT JOIN Users u ON d.created_by = u.id
       WHERE d.id = @id`,
      { id: { type: sql.UniqueIdentifier, value: id } }
    );
    return result.recordset[0] ? Device._parse(result.recordset[0]) : null;
  }

  static async findByIp(ip_address) {
    const result = await query(
      `SELECT * FROM Devices WHERE ip_address = @ip`,
      { ip: { type: sql.NVarChar(50), value: ip_address } }
    );
    return result.recordset[0] ? Device._parse(result.recordset[0]) : null;
  }

  static async findAll({ page = 1, limit = 50, status, device_type, search } = {}) {
    const offset = (page - 1) * limit;
    let where = 'WHERE 1=1';
    const params = {
      limit:  { type: sql.Int, value: limit },
      offset: { type: sql.Int, value: offset },
    };

    if (status)      { where += ' AND d.status = @status'; params.status = { type: sql.NVarChar(20), value: status }; }
    if (device_type) { where += ' AND d.device_type = @device_type'; params.device_type = { type: sql.NVarChar(50), value: device_type }; }
    if (search)      { where += ' AND (d.name LIKE @search OR d.ip_address LIKE @search)'; params.search = { type: sql.NVarChar(255), value: `%${search}%` }; }

    const countRes = await query(
      `SELECT COUNT(*) AS total FROM Devices d ${where}`,
      Object.fromEntries(Object.entries(params).filter(([k]) => !['limit','offset'].includes(k)))
    );

    const result = await query(
      `SELECT d.*, u.username AS created_by_name
       FROM Devices d
       LEFT JOIN Users u ON d.created_by = u.id
       ${where}
       ORDER BY d.name ASC
       OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY`,
      params
    );

    return {
      devices: result.recordset.map(Device._parse),
      total: countRes.recordset[0].total,
      page,
      limit,
    };
  }

  static async update(id, fields) {
    const allowed = ['name','ip_address','mac_address','device_type','location','status','metadata'];
    const setClauses = ['updated_at = GETUTCDATE()'];
    const params = { id: { type: sql.UniqueIdentifier, value: id } };

    for (const [key, val] of Object.entries(fields)) {
      if (!allowed.includes(key)) continue;
      setClauses.push(`${key} = @${key}`);
      if (key === 'metadata') {
        params[key] = { type: sql.NVarChar(sql.MAX), value: typeof val === 'object' ? JSON.stringify(val) : val };
      } else {
        params[key] = { type: sql.NVarChar(255), value: val };
      }
    }

    const result = await query(
      `UPDATE Devices SET ${setClauses.join(', ')} OUTPUT INSERTED.* WHERE id = @id`,
      params
    );
    return result.recordset[0] ? Device._parse(result.recordset[0]) : null;
  }

  static async updateStatus(id, status, last_seen = new Date()) {
    await query(
      `UPDATE Devices SET status = @status, last_seen = @last_seen, updated_at = GETUTCDATE()
       WHERE id = @id`,
      {
        id:        { type: sql.UniqueIdentifier, value: id },
        status:    { type: sql.NVarChar(20),     value: status },
        last_seen: { type: sql.DateTime2,        value: last_seen },
      }
    );
  }

  static async updateStatusByIp(ip, status) {
    await query(
      `UPDATE Devices SET status = @status, last_seen = GETUTCDATE(), updated_at = GETUTCDATE()
       WHERE ip_address = @ip`,
      {
        ip:     { type: sql.NVarChar(50), value: ip },
        status: { type: sql.NVarChar(20), value: status },
      }
    );
  }

  static async delete(id) {
    await query(
      `DELETE FROM Devices WHERE id = @id`,
      { id: { type: sql.UniqueIdentifier, value: id } }
    );
  }

  static async getStatusSummary() {
    const result = await query(
      `SELECT status, COUNT(*) AS count FROM Devices GROUP BY status`
    );
    return result.recordset;
  }

  static _parse(row) {
    if (!row) return null;
    return {
      ...row,
      metadata: row.metadata ? JSON.parse(row.metadata) : null,
    };
  }
}

module.exports = Device;
