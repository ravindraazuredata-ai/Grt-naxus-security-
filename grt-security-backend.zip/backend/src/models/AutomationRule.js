// src/models/AutomationRule.js
const { sql, query } = require('../config/database');

class AutomationRule {
  static async create({ name, description, trigger_type, trigger_config, action_type, action_config, created_by }) {
    const result = await query(
      `INSERT INTO AutomationRules
         (name, description, trigger_type, trigger_config, action_type, action_config, created_by)
       OUTPUT INSERTED.*
       VALUES (@name, @desc, @ttype, @tconfig, @atype, @aconfig, @created_by)`,
      {
        name:       { type: sql.NVarChar(150),     value: name },
        desc:       { type: sql.NVarChar(500),     value: description || null },
        ttype:      { type: sql.NVarChar(50),      value: trigger_type },
        tconfig:    { type: sql.NVarChar(sql.MAX), value: JSON.stringify(trigger_config) },
        atype:      { type: sql.NVarChar(50),      value: action_type },
        aconfig:    { type: sql.NVarChar(sql.MAX), value: JSON.stringify(action_config) },
        created_by: { type: sql.UniqueIdentifier,  value: created_by || null },
      }
    );
    return AutomationRule._parse(result.recordset[0]);
  }

  static async findById(id) {
    const result = await query(
      `SELECT r.*, u.username AS created_by_name
       FROM AutomationRules r
       LEFT JOIN Users u ON r.created_by = u.id
       WHERE r.id = @id`,
      { id: { type: sql.UniqueIdentifier, value: id } }
    );
    return result.recordset[0] ? AutomationRule._parse(result.recordset[0]) : null;
  }

  static async findAll({ page = 1, limit = 50, is_active } = {}) {
    const offset = (page - 1) * limit;
    let where = 'WHERE 1=1';
    const params = {
      limit:  { type: sql.Int, value: limit },
      offset: { type: sql.Int, value: offset },
    };

    if (is_active !== undefined) {
      where += ' AND r.is_active = @is_active';
      params.is_active = { type: sql.Bit, value: is_active ? 1 : 0 };
    }

    const result = await query(
      `SELECT r.*, u.username AS created_by_name
       FROM AutomationRules r
       LEFT JOIN Users u ON r.created_by = u.id
       ${where}
       ORDER BY r.created_at DESC
       OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY`,
      params
    );

    const countRes = await query(
      `SELECT COUNT(*) AS total FROM AutomationRules r ${where}`,
      Object.fromEntries(Object.entries(params).filter(([k]) => !['limit','offset'].includes(k)))
    );

    return {
      rules: result.recordset.map(AutomationRule._parse),
      total: countRes.recordset[0].total,
      page,
      limit,
    };
  }

  static async getActiveRules() {
    const result = await query(
      `SELECT * FROM AutomationRules WHERE is_active = 1 ORDER BY created_at ASC`
    );
    return result.recordset.map(AutomationRule._parse);
  }

  static async update(id, fields) {
    const allowed = ['name','description','trigger_type','trigger_config','action_type','action_config','is_active'];
    const setClauses = ['updated_at = GETUTCDATE()'];
    const params = { id: { type: sql.UniqueIdentifier, value: id } };

    for (const [key, val] of Object.entries(fields)) {
      if (!allowed.includes(key)) continue;
      setClauses.push(`${key} = @${key}`);
      if (['trigger_config','action_config'].includes(key)) {
        params[key] = { type: sql.NVarChar(sql.MAX), value: JSON.stringify(val) };
      } else if (key === 'is_active') {
        params[key] = { type: sql.Bit, value: val ? 1 : 0 };
      } else {
        params[key] = { type: sql.NVarChar(255), value: val };
      }
    }

    const result = await query(
      `UPDATE AutomationRules SET ${setClauses.join(', ')} OUTPUT INSERTED.* WHERE id = @id`,
      params
    );
    return result.recordset[0] ? AutomationRule._parse(result.recordset[0]) : null;
  }

  static async recordExecution(rule_id, status, result, error = null) {
    await query(
      `INSERT INTO AutomationLogs (rule_id, status, result, error) VALUES (@rule_id, @status, @result, @error);
       UPDATE AutomationRules SET last_triggered = GETUTCDATE(), trigger_count = trigger_count + 1 WHERE id = @rule_id`,
      {
        rule_id: { type: sql.UniqueIdentifier,   value: rule_id },
        status:  { type: sql.NVarChar(20),        value: status },
        result:  { type: sql.NVarChar(sql.MAX),   value: result ? JSON.stringify(result) : null },
        error:   { type: sql.NVarChar(sql.MAX),   value: error  || null },
      }
    );
  }

  static async getExecutionLogs(rule_id, limit = 20) {
    const result = await query(
      `SELECT TOP(@limit) * FROM AutomationLogs WHERE rule_id = @rule_id ORDER BY executed_at DESC`,
      {
        rule_id: { type: sql.UniqueIdentifier, value: rule_id },
        limit:   { type: sql.Int,              value: limit   },
      }
    );
    return result.recordset;
  }

  static async delete(id) {
    await query(
      `DELETE FROM AutomationRules WHERE id = @id`,
      { id: { type: sql.UniqueIdentifier, value: id } }
    );
  }

  static _parse(row) {
    if (!row) return null;
    return {
      ...row,
      trigger_config: typeof row.trigger_config === 'string' ? JSON.parse(row.trigger_config) : row.trigger_config,
      action_config:  typeof row.action_config  === 'string' ? JSON.parse(row.action_config)  : row.action_config,
    };
  }
}

module.exports = AutomationRule;
