// src/models/Alert.js
const { sql, query } = require('../config/database');

class Alert {
  static async create({ device_id, title, description, severity = 'info', category = 'general', metadata }) {
    const result = await query(
      `INSERT INTO Alerts (device_id, title, description, severity, category, metadata)
       OUTPUT INSERTED.*
       VALUES (@device_id, @title, @description, @severity, @category, @metadata)`,
      {
        device_id:   { type: sql.UniqueIdentifier,   value: device_id || null },
        title:       { type: sql.NVarChar(255),       value: title },
        description: { type: sql.NVarChar(sql.MAX),   value: description || null },
        severity:    { type: sql.NVarChar(20),        value: severity },
        category:    { type: sql.NVarChar(50),        value: category },
        metadata:    { type: sql.NVarChar(sql.MAX),   value: metadata ? JSON.stringify(metadata) : null },
      }
    );
    return Alert._parse(result.recordset[0]);
  }

  static async findById(id) {
    const result = await query(
      `SELECT a.*, d.name AS device_name, d.ip_address AS device_ip,
              u.username AS acknowledged_by_name
       FROM Alerts a
       LEFT JOIN Devices d ON a.device_id = d.id
       LEFT JOIN Users   u ON a.acknowledged_by = u.id
       WHERE a.id = @id`,
      { id: { type: sql.UniqueIdentifier, value: id } }
    );
    return result.recordset[0] ? Alert._parse(result.recordset[0]) : null;
  }

  static async findAll({ page = 1, limit = 50, status, severity, device_id, category, from_date, to_date } = {}) {
    const offset = (page - 1) * limit;
    let where = 'WHERE 1=1';
    const params = {
      limit:  { type: sql.Int, value: limit },
      offset: { type: sql.Int, value: offset },
    };

    if (status)    { where += ' AND a.status = @status';       params.status    = { type: sql.NVarChar(20),  value: status    }; }
    if (severity)  { where += ' AND a.severity = @severity';   params.severity  = { type: sql.NVarChar(20),  value: severity  }; }
    if (device_id) { where += ' AND a.device_id = @device_id'; params.device_id = { type: sql.UniqueIdentifier, value: device_id }; }
    if (category)  { where += ' AND a.category = @category';   params.category  = { type: sql.NVarChar(50),  value: category  }; }
    if (from_date) { where += ' AND a.created_at >= @from';    params.from      = { type: sql.DateTime2,     value: new Date(from_date) }; }
    if (to_date)   { where += ' AND a.created_at <= @to';      params.to        = { type: sql.DateTime2,     value: new Date(to_date)   }; }

    const countRes = await query(
      `SELECT COUNT(*) AS total FROM Alerts a ${where}`,
      Object.fromEntries(Object.entries(params).filter(([k]) => !['limit','offset'].includes(k)))
    );

    const result = await query(
      `SELECT a.*, d.name AS device_name, d.ip_address AS device_ip,
              u.username AS acknowledged_by_name
       FROM Alerts a
       LEFT JOIN Devices d ON a.device_id = d.id
       LEFT JOIN Users   u ON a.acknowledged_by = u.id
       ${where}
       ORDER BY
         CASE a.severity WHEN 'critical' THEN 1 WHEN 'high' THEN 2
                         WHEN 'medium' THEN 3    WHEN 'low' THEN 4 ELSE 5 END,
         a.created_at DESC
       OFFSET @offset ROWS FETCH NEXT @limit ROWS ONLY`,
      params
    );

    return {
      alerts: result.recordset.map(Alert._parse),
      total: countRes.recordset[0].total,
      page,
      limit,
    };
  }

  static async acknowledge(id, userId) {
    const result = await query(
      `UPDATE Alerts
       SET status = 'acknowledged', acknowledged_by = @user_id,
           acknowledged_at = GETUTCDATE(), updated_at = GETUTCDATE()
       OUTPUT INSERTED.*
       WHERE id = @id AND status = 'open'`,
      {
        id:      { type: sql.UniqueIdentifier, value: id },
        user_id: { type: sql.UniqueIdentifier, value: userId },
      }
    );
    return result.recordset[0] ? Alert._parse(result.recordset[0]) : null;
  }

  static async resolve(id) {
    const result = await query(
      `UPDATE Alerts
       SET status = 'resolved', resolved_at = GETUTCDATE(), updated_at = GETUTCDATE()
       OUTPUT INSERTED.*
       WHERE id = @id AND status IN ('open','acknowledged')`,
      { id: { type: sql.UniqueIdentifier, value: id } }
    );
    return result.recordset[0] ? Alert._parse(result.recordset[0]) : null;
  }

  static async getSeveritySummary() {
    const result = await query(
      `SELECT severity, status, COUNT(*) AS count
       FROM Alerts
       WHERE status NOT IN ('closed','resolved')
       GROUP BY severity, status`
    );
    return result.recordset;
  }

  static async getRecentCritical(limit = 10) {
    const result = await query(
      `SELECT TOP(@limit) a.*, d.name AS device_name
       FROM Alerts a
       LEFT JOIN Devices d ON a.device_id = d.id
       WHERE a.severity IN ('critical','high') AND a.status = 'open'
       ORDER BY a.created_at DESC`,
      { limit: { type: sql.Int, value: limit } }
    );
    return result.recordset.map(Alert._parse);
  }

  static _parse(row) {
    if (!row) return null;
    return {
      ...row,
      metadata: row.metadata ? JSON.parse(row.metadata) : null,
    };
  }
}

module.exports = Alert;
