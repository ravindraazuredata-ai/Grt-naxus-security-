// src/server.js
// ─────────────────────────────────────────────────────────────
//  GRT Assist Automations & Security Platform — API Server
// ─────────────────────────────────────────────────────────────
require('dotenv').config();

const http    = require('http');
const express = require('express');
const helmet  = require('helmet');
const cors    = require('cors');
const morgan  = require('morgan');
const rateLimit = require('express-rate-limit');

const { initializeSchema, closePool } = require('./config/database');
const logger = require('./utils/logger');

// ── Routes ────────────────────────────────────────────────────
const authRoutes          = require('./routes/auth');
const deviceRoutes        = require('./routes/devices');
const alertRoutes         = require('./routes/alerts');
const surveillanceRoutes  = require('./routes/surveillance');
const automationRoutes    = require('./routes/automation');
const notificationRoutes  = require('./routes/notifications');
const userRoutes          = require('./routes/users');
const aboutRoutes         = require('./routes/about');

// ── Middleware ────────────────────────────────────────────────
const { notFound, errorHandler } = require('./middleware/errorHandler');

// ── Services ──────────────────────────────────────────────────
const wsService       = require('./services/websocket');
const deviceScanning  = require('./services/deviceScanning');
const automationService = require('./services/automationService');
const notifService    = require('./services/notificationService');

// ─────────────────────────────────────────────────────────────
const app    = express();
const server = http.createServer(app);
const PORT   = process.env.PORT || 5000;

// ── Security & parsing ────────────────────────────────────────
app.use(helmet());
app.use(cors({
  origin:      process.env.CLIENT_ORIGIN || 'http://localhost:3000',
  credentials: true,
  methods:     ['GET','POST','PATCH','PUT','DELETE','OPTIONS'],
  allowedHeaders: ['Content-Type','Authorization'],
}));
app.use(express.json({ limit: '2mb' }));
app.use(express.urlencoded({ extended: true }));

// ── Logging ───────────────────────────────────────────────────
app.use(morgan('combined', {
  stream: { write: (msg) => logger.http(msg.trim()) },
  skip: (req) => req.url === '/api/about/health', // suppress noisy health pings
}));

// ── Global rate limiting ──────────────────────────────────────
app.use(rateLimit({
  windowMs: parseInt(process.env.RATE_LIMIT_WINDOW_MS, 10) || 15 * 60 * 1000,
  max:      parseInt(process.env.RATE_LIMIT_MAX_REQUESTS, 10) || 100,
  standardHeaders: true,
  legacyHeaders:   false,
  message: { success: false, message: 'Rate limit exceeded, please slow down.' },
}));

// ── Routes ────────────────────────────────────────────────────
app.use('/api/auth',          authRoutes);
app.use('/api/devices',       deviceRoutes);
app.use('/api/alerts',        alertRoutes);
app.use('/api/surveillance',  surveillanceRoutes);
app.use('/api/automation',    automationRoutes);
app.use('/api/notifications', notificationRoutes);
app.use('/api/users',         userRoutes);
app.use('/api/about',         aboutRoutes);

// ── 404 + global error handler ────────────────────────────────
app.use(notFound);
app.use(errorHandler);

// ─────────────────────────────────────────────────────────────
//  Bootstrap
// ─────────────────────────────────────────────────────────────
async function bootstrap() {
  try {
    // 1. Database schema
    await initializeSchema();

    // 2. WebSocket server
    wsService.init(server);

    // 3. Automation rules engine
    await automationService.init();

    // 4. Device scanner (first run immediately, then on schedule)
    deviceScanning.startScheduler();
    setTimeout(() => deviceScanning.checkAllDevices(), 5000); // initial check after 5s

    // 5. Email queue flush every 5 minutes
    setInterval(() => {
      notifService.flushEmailQueue().catch((err) =>
        logger.warn('Email queue flush error', { error: err.message })
      );
    }, 5 * 60 * 1000);

    // 6. Start listening
    server.listen(PORT, () => {
      logger.info(`🚀 GRT Security Platform API running on port ${PORT}`);
      logger.info(`   Environment : ${process.env.NODE_ENV || 'development'}`);
      logger.info(`   WebSocket   : ws://localhost:${PORT}/ws`);
      logger.info(`   Health      : http://localhost:${PORT}/api/about/health`);
    });
  } catch (err) {
    logger.error('Fatal: failed to start server', { error: err.message, stack: err.stack });
    process.exit(1);
  }
}

// ─────────────────────────────────────────────────────────────
//  Graceful shutdown
// ─────────────────────────────────────────────────────────────
async function shutdown(signal) {
  logger.info(`${signal} received — shutting down gracefully`);

  server.close(async () => {
    await closePool();
    logger.info('Server closed. Bye!');
    process.exit(0);
  });

  // Force exit after 15s
  setTimeout(() => {
    logger.error('Forced shutdown after timeout');
    process.exit(1);
  }, 15_000);
}

process.on('SIGTERM', () => shutdown('SIGTERM'));
process.on('SIGINT',  () => shutdown('SIGINT'));
process.on('unhandledRejection', (reason) => {
  logger.error('Unhandled promise rejection', { reason });
});
process.on('uncaughtException', (err) => {
  logger.error('Uncaught exception', { error: err.message, stack: err.stack });
  process.exit(1);
});

bootstrap();

module.exports = { app, server }; // for testing
