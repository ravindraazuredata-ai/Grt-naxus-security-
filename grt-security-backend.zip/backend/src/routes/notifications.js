// src/routes/notifications.js
const express      = require('express');
const Notification = require('../models/Notification');
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();
router.use(authenticate);

// ── GET /api/notifications ────────────────────────────────────
router.get('/', asyncHandler(async (req, res) => {
  const { page = 1, limit = 30, unread_only } = req.query;
  const result = await Notification.findForUser(req.user.id, {
    page: +page,
    limit: +limit,
    unread_only: unread_only === 'true',
  });
  res.json({ success: true, data: result });
}));

// ── GET /api/notifications/count ──────────────────────────────
router.get('/count', asyncHandler(async (req, res) => {
  const count = await Notification.unreadCount(req.user.id);
  res.json({ success: true, data: { unread_count: count } });
}));

// ── PATCH /api/notifications/:id/read ────────────────────────
router.patch('/:id/read', asyncHandler(async (req, res) => {
  await Notification.markRead(req.params.id, req.user.id);
  res.json({ success: true, message: 'Notification marked as read' });
}));

// ── PATCH /api/notifications/read-all ────────────────────────
router.patch('/read-all', asyncHandler(async (req, res) => {
  await Notification.markAllRead(req.user.id);
  res.json({ success: true, message: 'All notifications marked as read' });
}));

module.exports = router;
