// src/routes/devices.js
const express = require('express');
const Device  = require('../models/Device');
const { authenticate, authorize } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');
const { validate } = require('../validators/deviceValidator');
const deviceScanning = require('../services/deviceScanning');

const router = express.Router();

// All device routes require authentication
router.use(authenticate);

// ── GET /api/devices ──────────────────────────────────────────
router.get(
  '/',
  validate('query'),
  asyncHandler(async (req, res) => {
    const { page, limit, status, device_type, search } = req.query;
    const result = await Device.findAll({ page, limit, status, device_type, search });
    res.json({ success: true, data: result });
  })
);

// ── GET /api/devices/summary ──────────────────────────────────
router.get('/summary', asyncHandler(async (req, res) => {
  const summary = await Device.getStatusSummary();
  const totals = { online: 0, offline: 0, warning: 0, error: 0, total: 0 };
  summary.forEach(({ status, count }) => {
    totals[status] = count;
    totals.total += count;
  });
  res.json({ success: true, data: totals });
}));

// ── GET /api/devices/:id ──────────────────────────────────────
router.get('/:id', asyncHandler(async (req, res) => {
  const device = await Device.findById(req.params.id);
  if (!device) return res.status(404).json({ success: false, message: 'Device not found' });
  res.json({ success: true, data: { device } });
}));

// ── POST /api/devices ─────────────────────────────────────────
router.post(
  '/',
  authorize('admin', 'operator'),
  validate('create'),
  asyncHandler(async (req, res) => {
    const existing = await Device.findByIp(req.body.ip_address);
    if (existing) {
      return res.status(409).json({ success: false, message: 'A device with that IP already exists' });
    }

    const device = await Device.create({ ...req.body, created_by: req.user.id });
    res.status(201).json({ success: true, message: 'Device registered', data: { device } });
  })
);

// ── PATCH /api/devices/:id ────────────────────────────────────
router.patch(
  '/:id',
  authorize('admin', 'operator'),
  validate('update'),
  asyncHandler(async (req, res) => {
    const device = await Device.update(req.params.id, req.body);
    if (!device) return res.status(404).json({ success: false, message: 'Device not found' });
    res.json({ success: true, message: 'Device updated', data: { device } });
  })
);

// ── DELETE /api/devices/:id ───────────────────────────────────
router.delete(
  '/:id',
  authorize('admin'),
  asyncHandler(async (req, res) => {
    const device = await Device.findById(req.params.id);
    if (!device) return res.status(404).json({ success: false, message: 'Device not found' });
    await Device.delete(req.params.id);
    res.json({ success: true, message: 'Device removed' });
  })
);

// ── POST /api/devices/:id/ping ────────────────────────────────
router.post('/:id/ping', asyncHandler(async (req, res) => {
  const device = await Device.findById(req.params.id);
  if (!device) return res.status(404).json({ success: false, message: 'Device not found' });

  const alive = await deviceScanning.pingHost(device.ip_address);
  const newStatus = alive ? 'online' : 'offline';
  await Device.updateStatus(device.id, newStatus);

  res.json({ success: true, data: { alive, status: newStatus, ip: device.ip_address } });
}));

// ── POST /api/devices/scan ────────────────────────────────────
router.post(
  '/scan',
  authorize('admin', 'operator'),
  asyncHandler(async (req, res) => {
    const { subnet } = req.body;
    // Fire-and-forget; full results arrive via WebSocket
    deviceScanning.scanSubnet(subnet || process.env.SUBNET_RANGE).catch(() => {});
    res.json({ success: true, message: 'Network scan initiated — results will stream via WebSocket' });
  })
);

module.exports = router;
