// src/routes/surveillance.js
// ─────────────────────────────────────────────────────────────
//  Surveillance management — camera feeds, PTZ, snapshots.
//  Cameras are stored as Devices with device_type='camera'.
// ─────────────────────────────────────────────────────────────
const express = require('express');
const Device  = require('../models/Device');
const Alert   = require('../models/Alert');
const { authenticate, authorize } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();
router.use(authenticate);

// ── GET /api/surveillance/cameras ────────────────────────────
router.get('/cameras', asyncHandler(async (req, res) => {
  const { page = 1, limit = 50, status } = req.query;
  const result = await Device.findAll({
    page: +page, limit: +limit, status, device_type: 'camera',
  });
  res.json({ success: true, data: result });
}));

// ── GET /api/surveillance/cameras/:id ────────────────────────
router.get('/cameras/:id', asyncHandler(async (req, res) => {
  const camera = await Device.findById(req.params.id);
  if (!camera || camera.device_type !== 'camera') {
    return res.status(404).json({ success: false, message: 'Camera not found' });
  }
  res.json({ success: true, data: { camera } });
}));

// ── POST /api/surveillance/cameras ───────────────────────────
router.post(
  '/cameras',
  authorize('admin', 'operator'),
  asyncHandler(async (req, res) => {
    const { name, ip_address, location, metadata } = req.body;
    if (!name || !ip_address) {
      return res.status(400).json({ success: false, message: 'name and ip_address are required' });
    }

    const camera = await Device.create({
      name,
      ip_address,
      location,
      device_type: 'camera',
      metadata: {
        stream_url:    metadata?.stream_url    || `rtsp://${ip_address}/stream`,
        snapshot_url:  metadata?.snapshot_url  || `http://${ip_address}/snapshot`,
        resolution:    metadata?.resolution    || '1080p',
        fps:           metadata?.fps           || 25,
        ptz_enabled:   metadata?.ptz_enabled   || false,
        ...metadata,
      },
      created_by: req.user.id,
    });

    res.status(201).json({ success: true, message: 'Camera registered', data: { camera } });
  })
);

// ── GET /api/surveillance/cameras/:id/snapshot ───────────────
router.get('/cameras/:id/snapshot', asyncHandler(async (req, res) => {
  const camera = await Device.findById(req.params.id);
  if (!camera || camera.device_type !== 'camera') {
    return res.status(404).json({ success: false, message: 'Camera not found' });
  }

  const snapshotUrl = camera.metadata?.snapshot_url;
  if (!snapshotUrl) {
    return res.status(400).json({ success: false, message: 'No snapshot URL configured for this camera' });
  }

  // Return the URL for the client to fetch directly (avoids proxying large image data)
  res.json({ success: true, data: { snapshot_url: snapshotUrl, camera_id: camera.id } });
}));

// ── POST /api/surveillance/cameras/:id/ptz ───────────────────
router.post(
  '/cameras/:id/ptz',
  authorize('admin', 'operator'),
  asyncHandler(async (req, res) => {
    const camera = await Device.findById(req.params.id);
    if (!camera || camera.device_type !== 'camera') {
      return res.status(404).json({ success: false, message: 'Camera not found' });
    }
    if (!camera.metadata?.ptz_enabled) {
      return res.status(400).json({ success: false, message: 'PTZ not enabled for this camera' });
    }

    const { action, speed = 5 } = req.body; // action: pan-left|pan-right|tilt-up|tilt-down|zoom-in|zoom-out|home
    if (!action) return res.status(400).json({ success: false, message: 'action is required' });

    // In production, issue ONVIF or RTSP PTZ command here
    res.json({
      success: true,
      message: `PTZ command '${action}' sent at speed ${speed}`,
      data: { camera_id: camera.id, action, speed },
    });
  })
);

// ── GET /api/surveillance/motion-events ──────────────────────
router.get('/motion-events', asyncHandler(async (req, res) => {
  const { page = 1, limit = 30, device_id } = req.query;
  const result = await Alert.findAll({
    page: +page, limit: +limit, category: 'motion', device_id,
  });
  res.json({ success: true, data: result });
}));

// ── GET /api/surveillance/overview ───────────────────────────
router.get('/overview', asyncHandler(async (req, res) => {
  const [cameras, motionAlerts] = await Promise.all([
    Device.findAll({ limit: 200, device_type: 'camera' }),
    Alert.findAll({ limit: 10, category: 'motion', status: 'open' }),
  ]);

  const statusCounts = { online: 0, offline: 0, warning: 0, error: 0 };
  cameras.devices.forEach((c) => { statusCounts[c.status] = (statusCounts[c.status] || 0) + 1; });

  res.json({
    success: true,
    data: {
      total_cameras:   cameras.total,
      status_counts:   statusCounts,
      recent_motion:   motionAlerts.alerts,
    },
  });
}));

module.exports = router;
