// src/routes/alerts.js
const express = require('express');
const Alert   = require('../models/Alert');
const { authenticate, authorize } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();
router.use(authenticate);

// ── GET /api/alerts ───────────────────────────────────────────
router.get('/', asyncHandler(async (req, res) => {
  const { page = 1, limit = 50, status, severity, device_id, category, from_date, to_date } = req.query;
  const result = await Alert.findAll({
    page: +page, limit: +limit, status, severity, device_id, category, from_date, to_date,
  });
  res.json({ success: true, data: result });
}));

// ── GET /api/alerts/summary ───────────────────────────────────
router.get('/summary', asyncHandler(async (req, res) => {
  const [summary, recent] = await Promise.all([
    Alert.getSeveritySummary(),
    Alert.getRecentCritical(5),
  ]);
  res.json({ success: true, data: { summary, recent_critical: recent } });
}));

// ── GET /api/alerts/:id ───────────────────────────────────────
router.get('/:id', asyncHandler(async (req, res) => {
  const alert = await Alert.findById(req.params.id);
  if (!alert) return res.status(404).json({ success: false, message: 'Alert not found' });
  res.json({ success: true, data: { alert } });
}));

// ── POST /api/alerts ──────────────────────────────────────────
router.post(
  '/',
  authorize('admin', 'operator'),
  asyncHandler(async (req, res) => {
    const { device_id, title, description, severity, category, metadata } = req.body;
    if (!title) return res.status(400).json({ success: false, message: 'Title is required' });

    const alert = await Alert.create({ device_id, title, description, severity, category, metadata });
    res.status(201).json({ success: true, message: 'Alert created', data: { alert } });
  })
);

// ── PATCH /api/alerts/:id/acknowledge ────────────────────────
router.patch('/:id/acknowledge', asyncHandler(async (req, res) => {
  const alert = await Alert.acknowledge(req.params.id, req.user.id);
  if (!alert) {
    return res.status(400).json({
      success: false,
      message: 'Alert not found or already acknowledged',
    });
  }
  res.json({ success: true, message: 'Alert acknowledged', data: { alert } });
}));

// ── PATCH /api/alerts/:id/resolve ────────────────────────────
router.patch(
  '/:id/resolve',
  authorize('admin', 'operator'),
  asyncHandler(async (req, res) => {
    const alert = await Alert.resolve(req.params.id);
    if (!alert) {
      return res.status(400).json({
        success: false,
        message: 'Alert not found or already resolved',
      });
    }
    res.json({ success: true, message: 'Alert resolved', data: { alert } });
  })
);

module.exports = router;
