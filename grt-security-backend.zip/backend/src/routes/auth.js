// src/routes/auth.js
const express  = require('express');
const jwt      = require('jsonwebtoken');
const rateLimit = require('express-rate-limit');
const { sql, query } = require('../config/database');
const User     = require('../models/User');
const { validate } = require('../validators/authValidator');
const { authenticate } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');
const logger   = require('../utils/logger');

const router = express.Router();

// Strict rate limiting for auth endpoints
const authLimiter = rateLimit({
  windowMs: 15 * 60 * 1000,
  max: parseInt(process.env.AUTH_RATE_LIMIT_MAX, 10) || 10,
  message: { success: false, message: 'Too many attempts, please try again later' },
});

// ── POST /api/auth/register ───────────────────────────────────
router.post(
  '/register',
  authLimiter,
  validate('register'),
  asyncHandler(async (req, res) => {
    const { username, email, password, role } = req.body;

    const existing = await User.findByEmailRaw(email);
    if (existing) {
      return res.status(409).json({ success: false, message: 'Email already registered' });
    }

    const user = await User.create({ username, email, password, role });
    logger.info('User registered', { userId: user.id, email });

    res.status(201).json({ success: true, message: 'User created', data: { user } });
  })
);

// ── POST /api/auth/login ──────────────────────────────────────
router.post(
  '/login',
  authLimiter,
  validate('login'),
  asyncHandler(async (req, res) => {
    const { email, password } = req.body;

    const rawUser = await User.findByEmailRaw(email);
    if (!rawUser || !rawUser.is_active) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    const valid = await User.verifyPassword(password, rawUser.password);
    if (!valid) {
      return res.status(401).json({ success: false, message: 'Invalid credentials' });
    }

    const accessToken = jwt.sign(
      { id: rawUser.id, role: rawUser.role },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
    );

    const refreshToken = jwt.sign(
      { id: rawUser.id },
      process.env.JWT_REFRESH_SECRET,
      { expiresIn: process.env.JWT_REFRESH_EXPIRES_IN || '7d' }
    );

    // Persist refresh token
    const expiresAt = new Date(Date.now() + 7 * 24 * 60 * 60 * 1000);
    await query(
      `INSERT INTO RefreshTokens (user_id, token, expires_at) VALUES (@uid, @tok, @exp)`,
      {
        uid: { type: sql.UniqueIdentifier, value: rawUser.id },
        tok: { type: sql.NVarChar(512),    value: refreshToken },
        exp: { type: sql.DateTime2,        value: expiresAt },
      }
    );

    await User.touchLastLogin(rawUser.id);
    logger.info('User logged in', { userId: rawUser.id });

    const { password: _, ...user } = rawUser;

    res.json({
      success: true,
      data: { user, access_token: accessToken, refresh_token: refreshToken },
    });
  })
);

// ── POST /api/auth/refresh ────────────────────────────────────
router.post(
  '/refresh',
  validate('refreshToken'),
  asyncHandler(async (req, res) => {
    const { refresh_token } = req.body;

    let decoded;
    try {
      decoded = jwt.verify(refresh_token, process.env.JWT_REFRESH_SECRET);
    } catch {
      return res.status(401).json({ success: false, message: 'Invalid or expired refresh token' });
    }

    const stored = await query(
      `SELECT * FROM RefreshTokens WHERE token = @tok AND expires_at > GETUTCDATE()`,
      { tok: { type: sql.NVarChar(512), value: refresh_token } }
    );

    if (!stored.recordset.length) {
      return res.status(401).json({ success: false, message: 'Refresh token not found or expired' });
    }

    const user = await User.findById(decoded.id);
    if (!user) {
      return res.status(401).json({ success: false, message: 'User not found' });
    }

    const accessToken = jwt.sign(
      { id: user.id, role: user.role },
      process.env.JWT_SECRET,
      { expiresIn: process.env.JWT_EXPIRES_IN || '8h' }
    );

    res.json({ success: true, data: { access_token: accessToken } });
  })
);

// ── POST /api/auth/logout ─────────────────────────────────────
router.post(
  '/logout',
  authenticate,
  asyncHandler(async (req, res) => {
    const { refresh_token } = req.body;

    if (refresh_token) {
      await query(
        `DELETE FROM RefreshTokens WHERE token = @tok AND user_id = @uid`,
        {
          tok: { type: sql.NVarChar(512),    value: refresh_token },
          uid: { type: sql.UniqueIdentifier, value: req.user.id  },
        }
      );
    }

    logger.info('User logged out', { userId: req.user.id });
    res.json({ success: true, message: 'Logged out successfully' });
  })
);

// ── GET /api/auth/me ──────────────────────────────────────────
router.get('/me', authenticate, asyncHandler(async (req, res) => {
  res.json({ success: true, data: { user: req.user } });
}));

// ── PATCH /api/auth/change-password ───────────────────────────
router.patch(
  '/change-password',
  authenticate,
  validate('changePassword'),
  asyncHandler(async (req, res) => {
    const { current_password, new_password } = req.body;
    const rawUser = await User.findByEmailRaw(req.user.email);

    const valid = await User.verifyPassword(current_password, rawUser.password);
    if (!valid) {
      return res.status(400).json({ success: false, message: 'Current password is incorrect' });
    }

    await User.changePassword(req.user.id, new_password);
    // Invalidate all refresh tokens
    await query(
      `DELETE FROM RefreshTokens WHERE user_id = @uid`,
      { uid: { type: sql.UniqueIdentifier, value: req.user.id } }
    );

    logger.info('Password changed', { userId: req.user.id });
    res.json({ success: true, message: 'Password updated successfully' });
  })
);

module.exports = router;
