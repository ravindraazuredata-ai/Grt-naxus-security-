// src/routes/about.js
const express = require('express');
const { getPool } = require('../config/database');
const { optionalAuth } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();
const START_TIME = Date.now();

// ── GET /api/health ───────────────────────────────────────────
router.get('/health', asyncHandler(async (_req, res) => {
  let dbStatus = 'disconnected';
  try {
    const pool = await getPool();
    await pool.request().query('SELECT 1');
    dbStatus = 'connected';
  } catch { /* already offline */ }

  const uptimeSeconds = Math.floor((Date.now() - START_TIME) / 1000);

  res.status(dbStatus === 'connected' ? 200 : 503).json({
    success: dbStatus === 'connected',
    data: {
      status:  dbStatus === 'connected' ? 'healthy' : 'degraded',
      uptime:  uptimeSeconds,
      database: dbStatus,
      timestamp: new Date().toISOString(),
    },
  });
}));

// ── GET /api/about ────────────────────────────────────────────
router.get('/', optionalAuth, asyncHandler(async (_req, res) => {
  res.json({
    success: true,
    data: {
      name:        'GRT Security Platform API',
      description: 'Real-time security monitoring, device management, and automation engine',
      company:     'GRT Assist Automations & Security Pvt. Ltd.',
      version:     '1.0.0',
      environment: process.env.NODE_ENV || 'development',
      features: [
        'Device discovery & health monitoring',
        'Real-time alert engine',
        'Multi-channel notifications',
        'Surveillance camera management',
        'Automation rule engine',
        'Role-based access control',
        'WebSocket live updates',
      ],
      endpoints: {
        auth:          '/api/auth',
        devices:       '/api/devices',
        alerts:        '/api/alerts',
        surveillance:  '/api/surveillance',
        automation:    '/api/automation',
        notifications: '/api/notifications',
        users:         '/api/users',
        health:        '/api/about/health',
      },
    },
  });
}));

module.exports = router;
