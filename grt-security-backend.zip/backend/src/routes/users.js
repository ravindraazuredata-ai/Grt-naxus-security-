// src/routes/users.js
const express = require('express');
const User    = require('../models/User');
const { authenticate, authorize } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');
const { validate } = require('../validators/authValidator');

const router = express.Router();
router.use(authenticate);

// ── GET /api/users ────────────────────────────────────────────
router.get('/', authorize('admin'), asyncHandler(async (req, res) => {
  const { page = 1, limit = 20, role } = req.query;
  const result = await User.findAll({ page: +page, limit: +limit, role });
  res.json({ success: true, data: result });
}));

// ── GET /api/users/:id ────────────────────────────────────────
router.get('/:id', authorize('admin'), asyncHandler(async (req, res) => {
  const user = await User.findById(req.params.id);
  if (!user) return res.status(404).json({ success: false, message: 'User not found' });
  res.json({ success: true, data: { user } });
}));

// ── POST /api/users ───────────────────────────────────────────
router.post(
  '/',
  authorize('admin'),
  validate('register'),
  asyncHandler(async (req, res) => {
    const { username, email, password, role } = req.body;

    const existing = await User.findByEmailRaw(email);
    if (existing) {
      return res.status(409).json({ success: false, message: 'Email already registered' });
    }

    const user = await User.create({ username, email, password, role });
    res.status(201).json({ success: true, message: 'User created', data: { user } });
  })
);

// ── PATCH /api/users/:id ──────────────────────────────────────
router.patch('/:id', authorize('admin'), asyncHandler(async (req, res) => {
  const { username, email, role, is_active } = req.body;
  const user = await User.update(req.params.id, { username, email, role, is_active });
  if (!user) return res.status(404).json({ success: false, message: 'User not found' });
  res.json({ success: true, message: 'User updated', data: { user } });
}));

// ── DELETE /api/users/:id ─────────────────────────────────────
router.delete('/:id', authorize('admin'), asyncHandler(async (req, res) => {
  if (req.params.id === req.user.id) {
    return res.status(400).json({ success: false, message: 'You cannot deactivate your own account' });
  }
  await User.deactivate(req.params.id);
  res.json({ success: true, message: 'User deactivated' });
}));

// ── PATCH /api/users/:id/reset-password ──────────────────────
router.patch(
  '/:id/reset-password',
  authorize('admin'),
  asyncHandler(async (req, res) => {
    const { new_password } = req.body;
    if (!new_password || new_password.length < 8) {
      return res.status(400).json({ success: false, message: 'Password must be at least 8 characters' });
    }

    const user = await User.findById(req.params.id);
    if (!user) return res.status(404).json({ success: false, message: 'User not found' });

    await User.changePassword(req.params.id, new_password);
    res.json({ success: true, message: 'Password reset successfully' });
  })
);

module.exports = router;
