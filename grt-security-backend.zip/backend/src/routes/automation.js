// src/routes/automation.js
const express        = require('express');
const AutomationRule = require('../models/AutomationRule');
const automationService = require('../services/automationService');
const { authenticate, authorize } = require('../middleware/auth');
const { asyncHandler } = require('../middleware/errorHandler');

const router = express.Router();
router.use(authenticate);

const TRIGGER_TYPES = ['device_offline','alert_severity','schedule','device_status_change','alert_count'];
const ACTION_TYPES  = ['send_notification','send_email','create_alert','webhook','disable_device'];

// ── GET /api/automation/rules ─────────────────────────────────
router.get('/rules', asyncHandler(async (req, res) => {
  const { page = 1, limit = 50, is_active } = req.query;
  const result = await AutomationRule.findAll({
    page: +page,
    limit: +limit,
    is_active: is_active !== undefined ? is_active === 'true' : undefined,
  });
  res.json({ success: true, data: result });
}));

// ── GET /api/automation/rules/:id ────────────────────────────
router.get('/rules/:id', asyncHandler(async (req, res) => {
  const rule = await AutomationRule.findById(req.params.id);
  if (!rule) return res.status(404).json({ success: false, message: 'Rule not found' });
  res.json({ success: true, data: { rule } });
}));

// ── GET /api/automation/rules/:id/logs ───────────────────────
router.get('/rules/:id/logs', asyncHandler(async (req, res) => {
  const { limit = 20 } = req.query;
  const logs = await AutomationRule.getExecutionLogs(req.params.id, +limit);
  res.json({ success: true, data: { logs } });
}));

// ── POST /api/automation/rules ────────────────────────────────
router.post(
  '/rules',
  authorize('admin', 'operator'),
  asyncHandler(async (req, res) => {
    const { name, description, trigger_type, trigger_config, action_type, action_config } = req.body;

    if (!name || !trigger_type || !action_type || !trigger_config || !action_config) {
      return res.status(400).json({
        success: false,
        message: 'name, trigger_type, trigger_config, action_type, action_config are required',
      });
    }
    if (!TRIGGER_TYPES.includes(trigger_type)) {
      return res.status(400).json({ success: false, message: `Invalid trigger_type. Must be one of: ${TRIGGER_TYPES.join(', ')}` });
    }
    if (!ACTION_TYPES.includes(action_type)) {
      return res.status(400).json({ success: false, message: `Invalid action_type. Must be one of: ${ACTION_TYPES.join(', ')}` });
    }

    const rule = await AutomationRule.create({
      name, description, trigger_type, trigger_config, action_type, action_config,
      created_by: req.user.id,
    });

    // Hot-reload service
    await automationService.reloadRules();

    res.status(201).json({ success: true, message: 'Automation rule created', data: { rule } });
  })
);

// ── PATCH /api/automation/rules/:id ──────────────────────────
router.patch(
  '/rules/:id',
  authorize('admin', 'operator'),
  asyncHandler(async (req, res) => {
    const rule = await AutomationRule.update(req.params.id, req.body);
    if (!rule) return res.status(404).json({ success: false, message: 'Rule not found' });

    await automationService.reloadRules();
    res.json({ success: true, message: 'Rule updated', data: { rule } });
  })
);

// ── PATCH /api/automation/rules/:id/toggle ───────────────────
router.patch(
  '/rules/:id/toggle',
  authorize('admin', 'operator'),
  asyncHandler(async (req, res) => {
    const existing = await AutomationRule.findById(req.params.id);
    if (!existing) return res.status(404).json({ success: false, message: 'Rule not found' });

    const rule = await AutomationRule.update(req.params.id, { is_active: !existing.is_active });
    await automationService.reloadRules();

    res.json({
      success: true,
      message: `Rule ${rule.is_active ? 'enabled' : 'disabled'}`,
      data: { rule },
    });
  })
);

// ── POST /api/automation/rules/:id/test ──────────────────────
router.post(
  '/rules/:id/test',
  authorize('admin'),
  asyncHandler(async (req, res) => {
    const rule = await AutomationRule.findById(req.params.id);
    if (!rule) return res.status(404).json({ success: false, message: 'Rule not found' });

    const result = await automationService.testRule(rule, req.body.mock_event || {});
    res.json({ success: true, message: 'Test executed', data: { result } });
  })
);

// ── DELETE /api/automation/rules/:id ─────────────────────────
router.delete(
  '/rules/:id',
  authorize('admin'),
  asyncHandler(async (req, res) => {
    const rule = await AutomationRule.findById(req.params.id);
    if (!rule) return res.status(404).json({ success: false, message: 'Rule not found' });

    await AutomationRule.delete(req.params.id);
    await automationService.reloadRules();

    res.json({ success: true, message: 'Rule deleted' });
  })
);

// ── GET /api/automation/meta ──────────────────────────────────
router.get('/meta', asyncHandler(async (_req, res) => {
  res.json({
    success: true,
    data: {
      trigger_types: TRIGGER_TYPES,
      action_types: ACTION_TYPES,
      trigger_descriptions: {
        device_offline:          'Fires when a device goes offline',
        alert_severity:          'Fires when an alert of given severity is created',
        schedule:                'Fires on a cron schedule',
        device_status_change:    'Fires when a device status changes',
        alert_count:             'Fires when open alert count exceeds a threshold',
      },
      action_descriptions: {
        send_notification: 'Push in-app notification to users',
        send_email:        'Send email via SMTP',
        create_alert:      'Create a new alert record',
        webhook:           'POST to a configured HTTP endpoint',
        disable_device:    'Mark a device as offline/disabled',
      },
    },
  });
}));

module.exports = router;
